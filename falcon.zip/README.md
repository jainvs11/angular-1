
# Falcon UI Components Library
This is a project where all UI components are implemented

## Setup


### Install and build
** Assumption node and npm is installed

* run "npm install"
* run "npm run start"
* open browser http://localhost:8081/index.html to verify your component

### How to implement new component in IDE:

*   Create new directory under main with the name of the new component
*   Implement controller and directive for this new component
*   Import your new component module in customComponent.ts
*   Add new directive in the index.html





