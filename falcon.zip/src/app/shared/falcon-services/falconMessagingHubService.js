/**
 * Created by N097059 on 2/22/2016.
 */

var hubApp = angular.module("falcon.messaging.hub",[]);
hubApp.service('falconMessagingHubService',function ($window)
{
    this.topicSubscriberArray = new Array();
    this.messageBufferArray = new Array();
    this.init = function()
    {
        // attachEvent -- Works for Firefox and Chrome
        // addEventListener -- Works for IE and Opera
        var eventMethod = $window.addEventListener ? "addEventListener" : "attachEvent";
        var eventer = $window[eventMethod];
        var messageEvent = eventMethod == "attachEvent" ? "onmessage" : "message";
        var scope = this;

        /*
         * Listners on the window to handle postMessage event
         */
        eventer(messageEvent, function (event) {

            var requestObject = event.data;
            //console.log("In HUB eventer " + requestObject.operation );
            // ToDo -- the object shared will be a JSON .. need to think on this
            //var message = JSON.parse(obj);

            if (requestObject.operation === 'subscribe') {
                scope.subscribe(requestObject.topic, requestObject.subscriberId, requestObject.subscriberUrl, event.source);
            } else if (requestObject.operation === 'publish') {
                scope.publish(requestObject.topic, requestObject.payload);
            } else if (requestObject.operation === 'broadcast') {
                scope.broadcast(requestObject);
            }
        });
    };

    /*
     * Subscribes will be registered for a topic
     * topic -- topic the subscriber is interested to listen to
     * subscriberId -- unique Id for the scbscriber
     * subscriberUrl -- ToDo -- url to match the domain and port of the request
     * contentWindow -- window source of the scbscriber
     */
    this.subscribe = function(topic,subscriberId,subscriberUrl,contentWindow){
        //ToDo
        var subscribers = this.topicSubscriberArray[topic];
        if (subscribers==undefined) {
            subscribers = new Array();
            this.topicSubscriberArray[topic] = subscribers;
        }

        for (subscriber in subscribers){
            if (subscriberId == subscriber.id) {
                this.log("MH : Subscriber already subscribed");
                break;
            }
        }

        // If same subscriber calls subscribe event multiple times, the subscriber will be registered with last subscribe request details
        var subscriber = {id:subscriberId, url:subscriberUrl,contentWindow:contentWindow};
        subscribers[subscriberId] = subscriber;
    };

    /*
     * Hub/Subscriber can use publish on a topic to communicate with other subscriber
     * topic -- topic to publish
     * payload -- input data
     */
    this.publish = function(topic, payload){
        //console.log("in HUB publish topic "  + topic );
        if(!topic)
        {
            alert('problem in publish:no topic');
            return;
        }
        var subscribers = this.topicSubscriberArray[topic];
        var requestObject = {operation:'publish_from_hub',topic:topic,payload:payload};
        //if no subscribers are present discard the message
        if (subscribers==undefined) {
            alert('problem in publish:no subscriber');
            return;
        }

        for (id in subscribers) {
            var subscriber = subscribers[id];
            subscriber.contentWindow.postMessage(requestObject,'*');
        }
    };

    /*
     * Hub/Subscriber can use broadcast all subscriber which are registered
     * Application of this can be -- communicate sesion timeout, autosave, etc
     * payload -- input data
     */
    this.broadcast = function(payload){
        //ToDo
    };
});