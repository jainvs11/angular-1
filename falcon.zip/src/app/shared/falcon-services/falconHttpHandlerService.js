/**
 * Created by F539408 on 6/102/2016.
 */


var module = angular.module('falcon.http.handler', []);

module.service("falconHttpHandlerService", function($http)
{
    return {
        useGetHandler : function (params,
                                  handlerUrl)
        {
            return $http.get(handlerUrl, params);

        },

        usePostHandler : function (params,
                                   handlerUrl)
        {
            var config = {
                headers: {
                    'Accept': '*/*',
                    'Content-Type': 'application/json'
                }
            };

            return  $http.post(handlerUrl, params, config);

        }
    }
});

