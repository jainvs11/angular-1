/**
 * Created by F539408 on 6/13/2016.
 */

var ruleModule = angular.module('falcon.rules',[]);

ruleModule.service('falconRulesService', function()
{
    return {
        applyRulesService : function (lstUserInterface)
        {
            for (var iUIDto = 0; iUIDto < lstUserInterface.length; iUIDto++)
            {
                var uIDto = lstUserInterface[iUIDto];
                var elementId = "#" + uIDto.resourceId;
                var htmlElmt = angular.element(elementId);
                if (htmlElmt != undefined )
                {
                    var cusScope = htmlElmt.isolateScope();
                    if (typeof cusScope !== 'undefined'  && typeof cusScope.applyRules !== 'undefined' && typeof cusScope.applyRules  === 'function')
                    {
                        cusScope.applyRules(uIDto);
                    }
                }
            }
        }
    }
});
