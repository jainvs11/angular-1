/**
 *
 * Created by N591450 on 2/22/2016
 */
var hubApp = angular.module("falcon.messaging.client",[]);

hubApp.service('falconMessagingClientService', function($window,$rootScope,$log){

    this.createHubObj =   function (){
        var hubObj ={};
        hubObj.type = 'parent';
        hubObj.element = $window.parent;
        return hubObj;
    };

    this.createCaptisHubObj =   function (){
        var captisHubObj ={};
        captisHubObj.type    = 'iframe';
        var iframe = document.getElementById('captisIframe');
        if (iframe == undefined) {
            var merrorMsg = 'Messaging Client: error creating client. Invalid hub id specified for external client';
            // this.log(errorMsg);
            //throw errorMsg;
        }

        captisHubObj.element = document.getElementById('captisIframe').contentWindow;
        captisHubObj.url     = iframe.src;

        //captisHubObj.type    = 'parent';
        //captisHubObj.element = window.parent;
        //captisHubObj.url     = document.referrer;
        return captisHubObj;
    };

    this.hubObject = {};
    this.captisHub= {};
    this.subscriberId;

    this.init = function(subscriberId,subscribeEventArr,publishEventArr){
        this.subscriberId = subscriberId;
        $log.info('MC:'+subscriberId+':init in progress');
        // Listners on the window
        // attachEvent -- Works for Firefox and Chrome
        // addEventListener -- Works for IE and Opera
        var eventMethod = $window.addEventListener ? "addEventListener" : "attachEvent";
        var eventer = $window[eventMethod];
        var messageEvent = eventMethod == "attachEvent" ? "onmessage" : "message";
        var scope = this;

        scope.hubObject = scope.createHubObj();


        // Subscribe for all the events passed
        if(subscribeEventArr) {
            for (var subEveInd in subscribeEventArr) {
                scope.subscribe(subscribeEventArr[subEveInd],subscriberId);
            }
        }

        // Add listners on the publish events for all the events passed
        if(publishEventArr) {
            for (var pubEveInd in publishEventArr) {
                $rootScope.$on(publishEventArr[pubEveInd],function(event,payload){
                    scope.publish(event.name,payload);
                });
            }
        }

        eventer(messageEvent, function (event) {
            var requestObject = event.data;
            var message = (requestObject.topic ? requestObject : JSON.parse(requestObject));
            //console.log("In Client  eventer " + message.op );
            switch (message.op){
                // This is message from Hub
                case 'connect':
                    alert('received hub connect');
                    scope.log("Messaging Client: connect: Messaging Hub signalling init complete with id [" + message.value + "] for topic [" + message.topic + "] messageId [" + message.messageId + "]");
                    scope.callbackMessage({fn: callbackFn, scope: callbackScope}, message);
                    break;
                case 'hub':
                    scope.captisHub = scope.createCaptisHubObj();
                    //message is traveling downstream
                    if (message.subscriberIdList.length == 1) {
                        //message is meant for this subscriber, deliver the message
                      //  scope.log("Messaging Client: deliver message:  calling callback function on [" + _SUBSCRIBER_ID_ + "] for topic [" + message.topic + "] messageId [" + message.messageId + "]");
                        //scope.callbackMessage({fn: callbackFn, scope: callbackScope}, message);
                        scope.captisCallBackMethod(message);
                    }
                    else if (message.subscriberIdList.length == undefined) {
                        //message is meant for this subscriber, deliver the message
                        // scope.log("Messaging Client: deliver message:  calling callback function on [" + _SUBSCRIBER_ID_ + "] for topic [" + message.topic + "] messageId [" + message.messageId + "]");
                        //scope.callbackMessage({fn: callbackFn, scope: callbackScope}, message);
                        scope.callBackMethod(message);
                    }
                    break;
            }

            switch (requestObject.operation) {
                // This is message from Hub
                case 'publish_from_hub':
                    //console.log("In Client  eventer publish_from_hub requestObject.operation is" + requestObject.operation );
                    scope.callBackMethod(requestObject);
                    break;
            }


        });
    };


    this.captisCallBackMethod = function(requestObject) {
        $rootScope.$broadcast(requestObject.topic,requestObject.value);

        // The call back method call is one option of calling the subscriber code, however
        // with $rootScope we have far more flexibility with then handlers
        //callBackMethod.call($window,requestObject.topic, requestObject.payload);
    };



    /*
     * Call to hub - Subscribes will be registered for a topic
     * topic -- topic the subscriber is interested to listen to
     * subscriberId -- unique Id for the scbscriber
     */
    this.subscribe = function(topic,subscriberId)
    {
        var data = {operation: 'subscribe', topic: topic, subscriberId: subscriberId};
        $log.info('MC:subscribe:'+subscriberId+':subscribe request');
        this.postMessageToHub(this.hubObject,data);
    };

    this.subscribeCaptis = function(topic,subscriberId)
    {
        var data = {op: 'subscribe',clientType: 'external', topic: topic, subscriberIdList: [subscriberId]};
        $log.info('MC:subscribe:'+subscriberId+':subscribe request');
        this.dispatchMessage(this.captisHub,data);
    };

    /*
     * Subscriber can use publish on a topic to communicate with other subscriber/hub
     * topic -- topic to publish
     * payload -- input data
     */
    this.publish = function(topic, payload){
        if(topic) {
            var requestObject = {payload: payload, topic: topic, operation: 'publish'};
            $log.info('MC:publish:postMessage to hub '+topic);
            this.postMessageToHub(this.hubObject, requestObject);
        }
        else {
            $log.error('MC:publish:topic is blank');
        }
    };

    this.publishCaptis = function(topic, payload){
        if(topic) {
            // var requestObject = {payload: payload, topic: topic, operation: 'publish'};
            var data = {op: 'publish', topic: topic, value: payload, subscriberIdList: ['client1']};
            this.dispatchMessage(this.captisHub, data);
        }
        else {
            $log.error('MC:publish:topic is blank');
        }
    };


    this.dispatchMessage = function(address, message) {
        address.element.postMessage(JSON ? JSON.stringify(message) : message, address.url);
    }

    /*
     * clients callback method -- event handler
     */
    this.callBackMethod = function(requestObject,callBackMethod) {
        //console.log("In Client  callBackMethod requestObject.topic " + requestObject.topic );
        $rootScope.$broadcast(requestObject.topic,requestObject.payload);

        // The call back method call is one option of calling the subscriber code, however
        // with $rootScope we have far more flexibility with then handlers
        //callBackMethod.call($window,requestObject.topic, requestObject.payload);
    };

    /*
     *
     */
    this.postMessageToHub = function(hubObj,data){
        $log.info('in Client postMessageToHub '+ hubObj);
        hubObj.element.postMessage(data,'*');
    };

});