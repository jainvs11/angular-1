(function() {

    var componentController = function ComponentController($scope)
    {
        var vm = this;
        vm.$scope = $scope;
        vm.applyRules = function (userInterfaceDto)
        {
            if (userInterfaceDto.visible == true)
            {
                vm.$scope.visible = true;
                vm.$scope.disable = !userInterfaceDto.editable;
                vm.$scope.mandatory = userInterfaceDto.mandatory;
            }
            else
            {
                vm.$scope.visible = false;
            }
            if (vm.$scope.$root.$$phase != '$apply' && vm.$scope.$root.$$phase != '$digest')
            {
                vm.$scope.$apply();
            }
        };

        // only set defaults *if* not alread defined
        if ( ! angular.isDefined($scope.visible) )
        {
            $scope.visible = true;
        }
        if ( ! angular.isDefined($scope.disable) )
        {
            $scope.disable = false;
        }
        if ( ! angular.isDefined($scope.mandatory) )
        {
            $scope.mandatory = false;
        }

        $scope.cntrller = this;
        $scope.applyRules = this.applyRules;

    };

    angular.module('falcon.base.component.controller',[]).controller('falconBaseComponentController', componentController);
}());
