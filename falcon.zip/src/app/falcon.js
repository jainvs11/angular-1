define(["require", "exports", 'angular'], function (require, exports, angular) {
	"use strict";
    var fileUpload = require('angular-file-upload');
    var treeControl = require('treeControl');
    var uiSelect = require('uiSelect');
    var uiGridJS =require("angular-ui-grid-css")
    var uiGridCSS = require ('angular-ui-grid-js');
    var uiRouter = require('angular-ui-router');
    require("bootstrap-css");
    require("bootstrap-theme-css");
    require("bootstrap-js");
    var angularuibootstrap = require('ui-bootstrap');
    var angularuibootstraptmpl = require('ui-bootstrap-tpls');
    var jqueryui = require('jquery-ui');
    var ngAnimate = require('ngAnimate');
    var ngTouch = require ('ngtouch');
    var angularNotification = require ('angular-ui-notification-js');
    
    var falconAccordionDirective = require('./components/falcon-accordion/falconAccordionDirective');
    var falconButtonDirective = require('./components/falcon-button/falconButtonDirective');
    var falconDatePicker = require('./components/falcon-datepicker/falconDatePickerDirective');
    var falconDropdown = require('./components/falcon-dropdown/falconDropdownDirective');
    var falconCheckbox = require('./components/falcon-checkbox/falconCheckboxDirective');
    var falconGrid = require('./components/falcon-grid/falconGridDirective');
    var falconInput = require('./components/falcon-input/falconInputDirective');
    var falconLabel = require('./components/falcon-label/falconLabelDirective');
    var falconLeftNan = require('./components/falcon-leftnav/falconLeftnavDirective');
    var falconPopupController = require('./components/falcon-popup/falconPopupController');
    var falconRuleService = require('./shared/falcon-services/falconRulesService');
    var falconHttpHandlerService = require('./shared/falcon-services/falconHttpHandlerService');
    var falconMessagingClientService = require('./shared/falcon-services/falconMessagingClientService');
    var falconMessagingHubService = require('./shared/falcon-services/falconMessagingHubService');
    var falconBaseCompController = require('./shared/falcon-controllers/falconBaseComponentController');
    var falconNotification = require('./components/falcon-notification/falconNotificationDirective');

    var app = angular.module('falcon', ['ui.bootstrap', 'ui.bootstrap.tpls', 'treeControl', 'angularFileUpload', 'ngAnimate', 'ui-notification',
        'ui.grid', 'ui.grid.resizeColumns','ui.grid.moveColumns','ui.grid.selection','ui.grid.pagination', 'ui.grid.treeView', 'ui.select', 'ui.router',
        'falcon.label', 'falcon.accordion', 'falcon.button', 'falcon.datepicker', 'falcon.dropdown',  'falcon.checkbox', 'falcon.popup', 'falcon.input',
        'falcon.base.component.controller', 'falcon.grid','falcon.leftnav', 'falcon.rules', 'falcon.http.handler', 'falcon.messaging.client', 'falcon.messaging.hub','falcon.notification']);


    //app.controller('customPopupController', CustomPopup.PopupController.Factory);
    //app.directive('customAccordion', CustomAccordion.AccordionDirective.Factory);
    //app.directive('customAlertPopup', CustomAlertPopup.AlertPopupDirective.Factory);

    //app.directive('customCheckbox', CustomCheckbox.CheckboxDirective.Factory);
    //app.directive('customDatePicker', CustomDatePicker.DatePickerDirective.Factory);
    //app.directive('customDropdown', CustomDropdown.DropdownDirective.Factory);
    //app.directive('customDynamicTab', CustomDynamicTab.DynamicTabDirective.Factory);
    //app.directive('customFileModel', CustomFileUpload.FileUploadDirective.Factory);
    //app.directive('customGrid', CustomGrid.GridDirective.Factory);
    //app.directive('customHBox', CustomHBox.HBoxDirective.Factory);
    //app.directive('customHMenu', CustomMenu.HorizontalMenuDirective.Factory);
    //app.directive('customMenu', CustomMenu.ParentMenuDirective.Factory);
    //app.directive('customLabel', CustomLabel.LabelDirective.Factory);
    //app.directive('customMultiSelect', CustomMultiselectDropdown.MultiselectDropdownDirective.Factory);
    //app.directive('customPagination', CustomPagination.PaginationDirective.Factory);
    //app.directive('customPanel', CustomPanel.PanelDirective.Factory);
    //app.directive('customProgressBar', CustomProgressBar.ProgressBarDirective.Factory);
    //app.directive('customSideBar', CustomSideBar.SideBarDirective.Factory);
    //app.directive('customSpinnerSmall', CustomSpinner.SpinnerSmallDirective.Factory);
    //app.directive('customSpinnerMedium', CustomSpinner.SpinnerMediumDirective.Factory);
    //app.directive('customSpinnerLarge', CustomSpinner.SpinnerLargeDirective.Factory);
    //app.directive('customTab', CustomTab.TabDirective.Factory);
    //app.directive('customTabs', CustomTab.TabsDirective.Factory);
    //app.directive('customTextArea', CustomTextArea.TextAreaDirective.Factory);
    //app.directive('customTextInput', CustomTextInput.TextInputDirective.Factory);
    //app.directive('customTree', CustomTree.TreeDirective.Factory);
    //app.directive('customVBox', CustomVBox.VBoxDirective.Factory);
    //app.directive('resizeable', CustomWindow.ResizeableDirective.Factory);
    //app.directive('draggable', CustomWindow.DraggableDirective.Factory);
    //app.directive('window', CustomWindow.WindowDirective.Factory);
    //app.service('proxyService', ProxyServiceModule.ProxyService);
    //app.service('ruleService', RuleServiceModule.RuleService);
});