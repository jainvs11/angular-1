(function() {

    var app = angular.module('falcon.button',['ui.bootstrap','falcon.base.component.controller', 'falcon.label']);

    function ButtonController($scope, $controller,$element,$compile)
    {
        angular.extend(this, $controller('falconBaseComponentController', {$scope: $scope}));

        this.initTemplate($scope,$element,$compile);
    }

    ButtonController.prototype.initTemplate= function($scope,$element,$compile)
    {
        var buttonTemplate = '<button '+
            'id="{{id}}" '+
            'type="button" '+
            'class="btn btn-jpmm btn-default" '+
            'ng-click="onClick()" > '+
            '{{name}} '+
            '</button>';

        $compile($element.html(buttonTemplate).contents())($scope);
    }

    app.directive('falconButton', function ()
    {
        return {
            restrict: 'EA',
            controller: ButtonController,
            controllerAs: 'bController',
            replace: true,
            scope:
            {
                id: "@",
                disable: "=?",
                visible: "=?",
                mandatory: "=?",
                model: "=",
                name: "@",
                onClick: "&"
            },
            link : function($scope, $element, attr, ctrl)
            {
                if (attr.hasOwnProperty("visible"))
                {
                    function display()
                    {
                        if ($scope.visible === true)
                        {
                            $element.show();
                        }
                        else if($scope.visible === false)
                        {
                            $element.hide();
                        }
                    }
                    $scope.$watch("visible", display);
                    setTimeout(display, 0);
                }
            }
        };
    });

}());