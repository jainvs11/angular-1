(function() {

    var app = angular.module('falcon.input',['ui.bootstrap','falcon.base.component.controller','falcon.label']);

    function InputController($scope, $controller,$element,$compile)
    {
        angular.extend(this, $controller('falconBaseComponentController', {$scope: $scope}));

        // default values
        var labelObj = '';

        // if we are attaching a label to the dropdown, we need to add the label as
        // well as update the class definition accordingly
        if ( angular.isDefined($scope.labelName) )
        {
            labelObj = '<falcon-label-form label-align="{{labelAlign}}" value="{{labelName}}"></falcon-label-form>';
        }
        this.initTemplate($scope,$element,$compile,labelObj);
    }

    InputController.prototype.initTemplate= function($scope,$element,$compile,labelObj)
    {
        var inputTemplate = '<div class="col-sm-{{width}} col-md-{{width}} col-lg-{{width}} form-group" '+
                                            'id="{{id}}"> ' +
                                            labelObj +
                                            '<input  '+
                                                'class="input-jpmm form-control" '+
                                                'ng-disabled="disable" '+
                                                'type="text" '+
                                                'ng-model="model" '+
                                                'placeholder="{{textPlaceholder}}" /> '+
                                         '</div>';

        $compile($element.html(inputTemplate).contents())($scope);
    }

    app.directive('falconInput', function ()
    {
        return {
            restrict: 'E',
            controller: InputController,
            controllerAs: 'tiController',
            scope:
            {
                id: "@",
                disable: "=?",
                visible: "=?",
                mandatory: "=?",
                model: "=",
                textPlaceholder: "@",
                labelName: "@",
                labelAlign: "@",
                width: "@"
            },
            link : function($scope, $element, attr, ctrl)
            {
                if (attr.hasOwnProperty("visible"))
                {
                    function display()
                    {
                        if ($scope.visible === true)
                        {
                            $element.show();
                        }
                        else if($scope.visible === false)
                        {
                            $element.hide();
                        }
                    }
                    $scope.$watch("visible", display);
                    setTimeout(display, 0);
                }
            }
        };
    });
}());
