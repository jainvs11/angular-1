(function() {
    var templateUrl = require('./popupTemplate.html');
    var ngSanitize = require('ngSanitize');
    var ngDialog = require('ngDialog');
    var app = angular.module('falcon.popup', ['ui.bootstrap', 'ngDialog','ngSanitize', 'falcon.base.component.controller']);

    app.controller('falconPopupController', function($scope, $controller, ngDialog)
    {
        angular.extend(this, $controller('falconBaseComponentController', {$scope: $scope}));

        var vm = this;

        this.showPopup = function (message, title, actionButtonName, closeButtonName, ngClass, actionEventName, data) {
            vm.actionEventName = actionEventName;
            vm.data = data;
            vm.$scope.message = message;
            vm.$scope.title = title;
            vm.$scope.actionButtonName = actionButtonName;
            vm.$scope.closeButtonName = closeButtonName;
            if (!ngClass || ngClass === "") {
                ngClass = 'ngdialog-theme-default';
            }
            ngDialog.open({
                templateUrl:templateUrl,
                className: ngClass,
                closeByEscape: false,
                closeByDocument: false,
                controller: this,
                controllerAs: 'pc',
                scope: vm.$scope
            });
        };
        this.customClose = function () {
            ngDialog.close("", "No");
        };
        this.action = function () {
            vm.$scope.$emit(vm.actionEventName, vm.data);
            console.log("Event Emitted ::" + vm.actionEventName);
            ngDialog.close("", vm.actionEventName);
        }

        function init()
        {

        }

        init();
    });

}());
