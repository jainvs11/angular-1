(function() {

    var app = angular.module('falcon.dropdown',['ui.bootstrap','falcon.base.component.controller','falcon.label']);

    function DropdownController($scope, $controller,$element,$compile)
    {
        angular.extend(this, $controller('falconBaseComponentController', {$scope: $scope}));

        // default values
        var dropdownClass = 'input-jpmm';
        var labelObj = '';
        var placeholderObj = '';
        var optionsPropertyValue = '.id';
        var optionsPropertyName = angular.isDefined($scope.propertyName) ? $scope.propertyName : 'name';
        var dropdownChangeParamsValue = angular.isDefined($scope.dropdownChangeParams) ? $scope.dropdownChangeParams : '{message:selectedItem}';
        var trackByValue = angular.isDefined( $scope.trackBy ) ? ' track by item.'+$scope.trackBy : '';

        // if we are attaching a label to the dropdown, we need to add the label as
        // well as update the class definition accordingly
        if ( angular.isDefined($scope.labelName) )
        {
            dropdownClass = dropdownClass + ' form-control';
            labelObj = '<falcon-label-form label-align="{{labelAlign}}" value="{{labelName}}"></falcon-label-form>';
        }
        if ( angular.isDefined($scope.placeholder) && $scope.placeholder ==="true" )
        {
            var placeholderVal = angular.isDefined($scope.placeholderValue) ? $scope.placeholderValue : 'Select';
            placeholderObj = '<option value="">'+placeholderVal+'</option>';
        }
        if ( angular.isDefined($scope.propertyValue) )
        {
            optionsPropertyValue = $scope.propertyValue === "" ? '' : '.'+$scope.propertyValue;
        }

        // NOTE - dropdownItems should ONLY be undefined IF using the falconDropdownYesNo directive
        // since it's bound as "@".  Not setting dropdownItems for other dropdown directives where it's
        // bound using "=" will result in a runtime error since it's not assignable.
        if ( ! angular.isDefined($scope.dropdownItems) )
        {
            $scope.dropdownItems = [{id:1, name:"Yes"}, {id:2, name:"No"}];
        }

        this.initTemplate($scope,$element,$compile, labelObj, dropdownClass, placeholderObj,optionsPropertyName,
            optionsPropertyValue,dropdownChangeParamsValue,trackByValue);
    }

    DropdownController.prototype.initTemplate= function($scope,$element,$compile,labelObj,dropdownClass,placeholderObj,
                                                        optionsPropertyName,optionsPropertyValue,dropdownChangeParamsValue,trackByValue)
    {
        var dropdownTemplate = '<div class="col-sm-{{width}} col-md-{{width}} col-lg-{{width}} form-group" '+
            'id="{{id}}"> ' +
            labelObj +
            '<select class="' + dropdownClass + ' coltRemovePadding" ' +
            'ng-model="selectedItem" ' +
            'ng-options="item'+optionsPropertyValue+ ' as item.'+optionsPropertyName+' for item in dropdownItems'+
            trackByValue+'" '+
            'ng-change="dropdownChange('+dropdownChangeParamsValue+')"'+
            'ng-disabled="disable" >  '+
             placeholderObj
            '</select></div>';

        $compile($element.html(dropdownTemplate).contents())($scope);
    }

    app.directive('falconDropdown', function ()
    {
        return {
            restrict: 'E',
            controller: DropdownController,
            controllerAs: 'dController',
            scope:
            {
                id: "@",
                disable: "=?",
                visible: "=?",
                mandatory: "=?",
                selectedItem: "=",
                dropdownItems: "=",
                labelName: "@",
                labelAlign: "@",
                width: "@",
                placeholder: "@",
                placeholderValue: "@",
                dropdownChange: "&",
                propertyName: "@",
                propertyValue: "@",
                dropdownChangeParams: "@",
                trackBy: "@"
            },
            link : function($scope, $element, attr, ctrl)
            {
                if (attr.hasOwnProperty("visible"))
                {
                    function display()
                    {
                        if ($scope.visible === true)
                        {
                            $element.show();
                        }
                        else if($scope.visible === false)
                        {
                            $element.hide();
                        }
                    }
                    $scope.$watch("visible", display);
                    setTimeout(ngShow, 0);
                }
            }
        };
    });

    app.directive('falconDropdownYesNo', function ()
    {
        return {
            restrict: 'E',
            controller: DropdownController,
            controllerAs: 'dController',
            scope:
            {
                id: "@",
                disable: "=?",
                visible: "=?",
                mandatory: "=?",
                selectedItem: "=",
                dropdownItems: "@",
                labelName: "@",
                labelAlign: "@",
                width: "@",
                placeholder: "@",
                placeholderValue: "@",
                dropdownChange: "&",
                propertyName: "@",
                propertyValue: "@",
                dropdownChangeParams: "@",
                trackBy: "@"
            },
            link : function($scope, $element, attr, ctrl)
            {
                if (attr.hasOwnProperty("visible"))
                {
                    function display()
                    {
                        if ($scope.visible === true)
                        {
                            $element.show();
                        }
                        else if($scope.visible === false)
                        {
                            $element.hide();
                        }
                    }
                    $scope.$watch("visible", display);
                    setTimeout(display, 0);
                }
            }
        };
    });
}());
