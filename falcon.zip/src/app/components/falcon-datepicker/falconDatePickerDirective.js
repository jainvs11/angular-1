(function() {

    var app = angular.module('falcon.datepicker',['ui.bootstrap','falcon.base.component.controller', 'falcon.label']);

    function DatePickerController($scope, $controller,$element,$compile)
    {
        angular.extend(this, $controller('falconBaseComponentController', {$scope: $scope}));

        // default values
        var labelObj = '';

        var vm = this;

        vm.today = function () {
            vm.pickedDate = new Date();
        };
        vm.open = function () {
            vm.popup.opened = true;
        };
        vm.clear = function () {
            vm.pickedDate = null;
        };
        vm.disabled = function (date, mode) {
            return mode === 'day' && (date.getDay() === 0 || date.getDay() === 6);
        };
        vm.toggleMin = function () {
            vm.minDate = vm.minDate ? null : new Date();
        };
        vm.setDate = function (year, month, day) {
            vm.pickedDate = new Date(year, month, day);
        };
        vm.getDayClass = function (date, mode) {
            if (mode === 'day') {
                var dayToCheck = new Date(date).setHours(0, 0, 0, 0);
                for (var i = 0; i < vm.events.length; i++) {
                    var currentDay = new Date(vm.events[i].date).setHours(0, 0, 0, 0);
                    if (dayToCheck === currentDay) {
                        return vm.events[i].status;
                    }
                }
            }
            return '';
        };

        tomorrow = function () {
            var date = new Date();
            date.setDate(1);
            return date;
        };
        afterTomorrow = function () {
            var date = new Date();
            date.setDate(2);
            return date;
        };

        function init() {
            vm.date = new Date();
            vm.maxDate = new Date(2099, 12, 31);
            vm.formats = ['M/dd/yyyy', 'dd-MMMM-yyyy', 'yyyy/MM/dd', 'dd.MM.yyyy', 'shortDate'];
            vm.format = vm.formats[0];
            vm.altInputFormats = ['M!/d!/yyyy'];
            vm.dateOptions = {
                formatYear: 'yy',
                startingDay: 1
            };
            vm.popup = {
                opened: false
            };
            vm.events = [
                {
                    date: tomorrow(),
                    status: 'full'
                },
                {
                    date: afterTomorrow(),
                    status: 'partially'
                }];
        };


        init();

        // if we are attaching a label to the datePicker, we need to enhance the top div
        if ( angular.isDefined($scope.labelName) )
        {
            labelObj = '<falcon-label-form label-align="{{labelAlign}}" value="{{labelName}}"></falcon-label-form>';
        }
        this.initTemplate($scope,$element,$compile,labelObj);
    }

    DatePickerController.prototype.initTemplate= function($scope,$element,$compile,labelObj)
    {
        var datepickerTemplate = '<div class="col-sm-{{width}} col-md-{{width}} col-lg-{{width}} btn-group" '+
            'id="{{id}}"> '+labelObj +' \
                                            <span \
                                                class="row-fluid"> \
                                                <span \
                                                    class="input-group"> \
                                                    <input \
                                                        datepicker-append-to-body=true \
                                                        placeholder="{{placeholder}}" \
                                                        type="text" \
                                                        class="form-control  gridDatePicker falcon-border-white" \
                                                        uib-datepicker-popup="{{dpController.format}}" \
                                                        ng-model="model" \
                                                        is-open="dpController.popup.opened" \
                                                        max-date="dpController.maxDate" \
                                                        datepicker-options="dpController.dateOptions" \
                                                        date-disabled="dpController.disabled(date, mode)" \
                                                        ng-required="mandatory" \
                                                        close-text="Close" \
                                                        alt-input-formats="dpController.altInputFormats"/> \
                                                        <span \
                                                            class="input-group-btn"> \
                                                            <button \
                                                                type="button" \
                                                                class="btn btn-default gridIconDatePicker" \
                                                                ng-click="dpController.open()"> \
                                                                <i \
                                                                    class="glyphicon glyphicon-calendar"> \
                                                                </i> \
                                                            </button> \
                                                        </span> \
                                                    </span> \
                                                </span> \
                                            </div>';

        $compile($element.html(datepickerTemplate).contents())($scope);
    }

    app.directive('falconDatePicker', function ()
    {
        return {
            restrict: 'E',
            controller: DatePickerController,
            controllerAs: 'dpController',
            replace: true,
            scope:
            {
                id: "@",
                disable: "=?",
                visible: "=?",
                mandatory: "=?",
                model: "=",
                labelName: "@",
                labelAlign: "@",
                width: "@",
                placeholder:"@"
            },
            link : function($scope, $element, attr, ctrl)
            {
                if (attr.hasOwnProperty("visible"))
                {
                    function display()
                    {
                        if ($scope.visible === true)
                        {
                            $element.show();
                        }
                        else if($scope.visible === false)
                        {
                            $element.hide();
                        }
                    }
                    $scope.$watch("visible", display);
                    setTimeout(display, 0);
                }
            }
        };
    });
}());
