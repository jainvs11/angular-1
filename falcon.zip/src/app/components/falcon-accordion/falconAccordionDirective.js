(function() {

    var app = angular.module('falcon.accordion',['ui.bootstrap','falcon.base.component.controller']);

    var accordionController = function($scope, $controller)
    {
        angular.extend(this, $controller('falconBaseComponentController', {$scope: $scope}));

        var AccordionGroup = (function ()
        {
            function AccordionGroup()
            {
                this.title = null;
                this.content = null;
                this.isOpen = false;
            }
            return AccordionGroup;
        }());
    };

    app.directive('falconAccordion', function ()
    {
        var accordionTemplate = '<uib-accordion \
                                            id="{{id}}" \
                                            close-others="aController.oneAtATime"> \
                                            <uib-accordion-group \
                                                heading="{{group.title}}" \
                                                is-open="group.isOpen" \
                                                ng-repeat="group in accordionGroups"> \
                                                {{group.content}} \
                                            </uib-accordion-group> \
                                        </uib-accordion>';

        return {
            restrict: 'E',
            controller: accordionController,
            controllerAs: 'aController',
            replace: false,
            scope:
            {
                id: "@",
                disable: "=?",
                visible: "=?",
                mandatory: "=?",
                accordionGroups: "="
            },
            template: accordionTemplate
        };
    });

}());