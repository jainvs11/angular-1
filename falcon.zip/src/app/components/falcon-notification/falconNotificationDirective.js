(function(){
		
	var app = angular.module('falcon.notification',['ui-notification']);
	
	app.config(function(NotificationProvider) {
		//Base Notification configurations
		NotificationProvider.setOptions({
			delay:100000,
			startTop:80,
			positionY:"right",
			closeOnClick:0,
			maxCount:!0
		});
	});
	
	function notificationController($scope, $controller,$element,$compile,Notification){
		 
		angular.extend(this, $controller('falconBaseComponentController', {$scope: $scope}));
		
		$scope.showNotifications = true;
		$scope.showNotMsg = true;
		$scope.showDetail  = false;
		$scope.iconClass = "glyphicon glyphicon-exclamation-sign unreadIcon";
		$scope.EmtArr = [{noNotifications: true}];
        
		//Clearing(hiding) the notifications once the user moves out from the notification
		$scope.hideNote = function(){
			Notification.clearAll();
			$scope.onClose();
		}
		
		
		
        //displaying icons based upon read and unread counts, changing the read and unread counts.
		$scope.cnt_msg = function(){
			var val = $scope.nElements[0];
			var count = 0;
		
			if( val.unread_cnt){
				count =  "("+val.unread_cnt+")";
				$scope.iconClass = "glyphicon glyphicon-exclamation-sign unreadIcon";
			}else if(val.read_cnt){
				count =  "("+val.read_cnt+")";
				$scope.iconClass = "glyphicon glyphicon-info-sign readIcon";
				
			}else{
				val.noNotifications = true;
				count = "";
				$scope.iconClass = "glyphicon glyphicon-info-sign noIcon";
				
			}
			return count;
		};
		
		//Showing the Notification Once hovering on the notifications button
		$scope.customTemplateScope = function($event) {
			if($scope.showNotifications){
				 $event.stopPropagation();
				 Notification.primary({message: "Notifications", templateUrl: "custom_template.html", scope: $scope, positionX: 'right'});
				 $scope.showNotifications = true;
				 if(!$scope.showNotifications){
					Notification.clearAll();
				}
			}
		}
		
		//Removing all the notifications
		$scope.clearAll= function(){
			Notification.clearAll();
		}
		
		//incase of no notifications from the webservice
		if(typeof $scope.nElements == 'undefined' || $scope.nElements.length == 0 ){
			$scope.nElements = [];
			$scope.nElements[0]={};
			$scope.nElements[0].noNotifications = true;
		}else if(typeof $scope.nElements[0].notification_list =='undefined' || $scope.nElements[0].notification_list.length == 0){
			var notificationElements = $scope.nElements;
			$scope.nElements = [];
			var read_cnt = 0;
			var unread_cnt = 0;
			var noNotifications = false;
			var total_msg_cnt = notificationElements.length;
			$scope.nElements[0] = {};
			$scope.nElements[0].sid = notificationElements[0].sid;
			$scope.nElements[0].total_msg_cnt = total_msg_cnt;
			$scope.nElements[0].notification_list = [];
			angular.forEach(notificationElements, function(notification, key){
				var obj = {};
				var len = notification.message.length;
				if(len >=50){
					obj.msg = notification.message.substring(0, 50);
					obj.dtl_msg =  notification.message.substring(50);
				}else{
					obj.msg = notification.message;
				}
				obj.id = notification.id;
				obj.action = notification.action;
				obj.createDate = notification.createDate;
				obj.createdBy = notification.createdBy;
				obj.modifyDate= notification.modifyDate;
				obj.modifiedBy= notification.modifiedBy;
				obj.dismissed = notification.dismissed;
				obj.read = notification.read;
				if(notification.read == 'Y'){
					read_cnt++;
				}else{
					unread_cnt++;
				}
				
				$scope.nElements[0].notification_list.push(obj);	
			});
			
			$scope.nElements[0].read_cnt = read_cnt;
			$scope.nElements[0].unread_cnt = unread_cnt;
			if(parseInt(unread_cnt) == 0 && parseInt(read_cnt) == 0){
				noNotifications = true;
			}
			$scope.nElements[0].noNotifications = noNotifications;
			
		}
		
        this.initTemplate($scope,$element,$compile, $scope.nElements);
           
		
	}
	
	notificationController.prototype.initTemplate= function($scope,$element,$compile)
	{
		
	        var notificationTemplate = '<div class="btn-group-vertical" ng-if="nElements" id="notification-div">\
	            <falcon-button ng-disabled="nElements[0].noNotifications" id="notification_btn" ng-mouseenter="customTemplateScope($event)"><span ng-class=\'iconClass\'></span>{{cnt_msg()}}</falcon-button>\
	            </div>\
	        	<script type="text/ng-template" id="custom_template.html">\
		        <div ng-mouseleave="hideNote()" ng-show="showNotifications"  class="ui-notification custom-template">\
	            <div class="message" ng-bind-html="message"></div>\
	            <div class="message">\
	                <ul>'+
	                    '<li class="txt" ng-repeat="el in nElements" style="clear:right">\
							<div ng-repeat="notification in el.notification_list">\
								<div ng-show="notification.dismissed == \'Y\'? false : true">\
								<span ng-click="change(notification);" ng-class="notification.read == \'N\'? \'bold\' : \'normal\'">\
									{{notification.msg}}\
									<span ng-if="!showDetail && notification.dtl_msg">...</span>\
								</span>\
								<span ng-if="showDetail">{{notification.dtl_msg}}</span>\
								<span>\
				<span class="linkTag" ng-click="showDetail= !showDetail;change(notification)">\
										<span ng-if="!showDetail && notification.dtl_msg">more</span>\
										<span ng-if="showDetail && notification.dtl_msg">less</span>\
									</span>\
								</span>\
								<div class="dismissDiv">\
									<span class="linkTag" ng-click="dismissNotification(notification,$index)">Dismiss</span>\
								</div>\
								<hr style="clear:right"/>\
								</div>\
							</div>\
						</li>\
						<span><span class="linkTag" ng-click="dismissAll()">Clear all</span></span></ul></div></div></script>'	;

	        $compile($element.html(notificationTemplate).contents())($scope);
	}
		
	
	app.directive('falconNotification',function(){
		return{
			restrict:'EA',
			controller : notificationController,
			scope:{
				  nElements: "=?notification",
				  onClose: "&close"
				
			},
			link: function($scope,ele,attr){
				//if notification attribute is not defined
				if(typeof attr.notification == 'undefined'){
					attr.notification = $scope.EmtArr;
					$scope.nElements = attr.notification;
				}
				//dismiss each notification
				$scope.dismissNotification = function(notification,index){
					notification.dismissed = 'Y';
					if($scope.nElements[0].total_msg_cnt != 0){
						$scope.nElements[0].total_msg_cnt--;
						if(notification.read == 'N' && $scope.nElements[0].unread_cnt > 0){
							notification.read = 'Y';
							$scope.nElements[0].unread_cnt--;
						}else{
							$scope.nElements[0].read_cnt--;
						}
							
					}
					else{
						$scope.nElements[0].noNotifications = true;
						$scope.clearAll();
						$scope.showNotifications = false;
						$scope.onClose();
					}
				
			}
				
			//converting notification to read from unread
			$scope.change = function(notification){
				//console.log("changing");
				 if(notification.read == 'N'){
					notification.read ='Y';
					$scope.nElements[0].read_cnt++;
					$scope.nElements[0].unread_cnt--;
				}
			}
			
			//Expanding and compressing the notification
			$scope.showMore = function(notification){
				$scope.showDetail = !$scope.showDetail;
				$scope.change(notification);
			}
			
			//Clearing all(Dismissing all) notifications
			$scope.dismissAll = function(){
				//console.log("dismissing all");
				//console.log("Elements"+$scope.nElements);
				$scope.onClose();
				$scope.clearAll();
				$scope.nElements[0].noNotifications = true;
				//$scope.showNotifications = false;
				$scope.nElements[0].read_cnt = 0;
				$scope.nElements[0].unread_cnt = 0;
				$scope.showReadIcon = false;
				$scope.showUnReadIcon = false;
				$scope.showNoIcon = true;
				angular.forEach($scope.nElements[0].notification_list, function(notification, key){
					notification.dismissed = 'Y';
					notification.read ='Y';
					
				});
				
				
			}
				
			}
		
			
		};
		
	});
	
})();