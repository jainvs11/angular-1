(function() {
    var app = angular.module('falcon.grid', ['ui.bootstrap', 'falcon.base.component.controller']);
    function GridController($scope, $controller, $element, $compile, $timeout,gridClassFactory) {
        angular.extend(this, $controller('falconBaseComponentController', {
            $scope: $scope
        }));
        $scope.gridOptions = $scope.gridConfig;
        this.initTemplate($scope, $element, $compile);
        this.handleExternalActions($scope, $timeout);
    };

    GridController.prototype.initTemplate = function($scope, $element, $compile) {
        /*if(angular.isUndefined($scope.gridConfig.data)){
        	return $element.html('<div class="alert alert-warning"> <a href="#" class="close" data-dismiss="alert">&times;</a> <strong>Warning!</strong> There was no data to be rendered. </div>').contents();
        }*/
        var baseTemplate = $element.html('<div id=\"{{id}}\" style="{{style}}" ui-grid=\"gridOptions\"></div>').contents();
        if (angular.isDefined($scope.gridConfig)) {
        	
            if ($scope.gridConfig.enableColumnMoving === true) {
                baseTemplate.attr("ui-grid-move-Columns", "");
                baseTemplate.attr("ui-grid-resize-columns", "");
            }
            if ($scope.gridConfig.enableRowSelection === true && $scope.gridConfig.enableSelectAll === true) {
                baseTemplate.attr("ui-grid-selection", "");
            }
            if ($scope.gridConfig.enablePagination === true) {
                baseTemplate.attr("ui-grid-pagination", "");
            }
            $compile(baseTemplate)($scope);
        };
    }
    /**
     * This method handles the external features Pagination,Sorting & Filtering.This method calls the client 
     * function callback with filtered config object
     */
    GridController.prototype.handleExternalActions = function($scope, $timeout) {

        if (this.isEnabledExternalActions($scope.gridConfig)) {
            var filterConfig = {};
            $scope.gridOptions.onRegisterApi = function(gridApi) {
                //Sorting
                if ($scope.gridConfig.useExternalSorting) {
                    gridApi.core.on.sortChanged($scope, function(grid, sortColumns) {
                        console.error(sortColumns)
                        if (sortColumns.length > 0) {
                            filterConfig.field = sortColumns[0].field;
                            filterConfig.sortType = sortColumns[0].sort.direction
                        }
                        $scope.gridConfig.sortCallBackFn(filterConfig);
                    });
                }

                //Pagination
                if ($scope.gridConfig.useExternalPagination) {
                    gridApi.pagination.on.paginationChanged($scope, function(newPage, pageSize) {
                        filterConfig.pageNumber = newPage;
                        filterConfig.pageSize = pageSize;
                        $scope.gridConfig.paginationCallBackFn(filterConfig);
                    });
                }
                
                //Row selection
                if($scope.gridConfig.enableRowSelection === true){
	                gridApi.selection.on.rowSelectionChanged($scope, function() {
	        			$scope.gridConfig.rowSelectionCallBackFn(angular.copy(gridApi.selection
	        					.getSelectedRows()));
	        		});
                }

                // Filtering / Searching
                if ($scope.gridConfig.useExternalFiltering) {
                    var searchFieldMap = {};
                    gridApi.core.on.filterChanged($scope, function() {
                        var grid = this.grid;
                        angular.forEach(grid.columns, function(value, key) {
                            if (angular.isDefined(value.filters[0].term)) {
                                if (value.filters[0].term == null || value.filters[0].term.length == 0) {
                                    delete searchFieldMap[value.colDef.field];
                                } else {
                                    var searchParamObj = {};
                                    searchParamObj.attributeName = value.colDef.field;
                                    searchParamObj.attributeValue = value.filters[0].term;
                                    searchParamObj.attributeType = value.colDef.type;
                                    searchFieldMap[value.colDef.field] = searchParamObj;
                                }
                            }
                            if (angular.isDefined($scope.filterTimeout)) {
                                $timeout.cancel($scope.filterTimeout);
                            }
                            $scope.filterTimeout = $timeout(function() {
                                filterConfig.searchParams = [];
                                for (key in searchFieldMap) {
                                    filterConfig.searchParams.push(searchFieldMap[key]);
                                }
                                $scope.gridConfig.filterCallBackFn(filterConfig);
                            }, 500);
                        });
                    });
                }

            }
        }
    }
    
    GridController.prototype.isEnabledExternalActions = function(config) {
        return (config.useExternalPagination === true || config.useExternalSorting === true || config.enableRowSelection === true || config.useExternalFiltering === true )
    }
    
    app.directive('falconGrid', function() {
        return {
            restrict: "E",
            scope: {
                id: '@',
                disable: "=?",
                visible: "=?",
                mandatory: "=?",
                gridConfig: '=',
                style:'@'
            },
            controller: GridController,
            controllerAs: 'ctrl'
        };
    });

}());