(function() {

    var app = angular.module('falcon.checkbox',['ui.bootstrap','falcon.base.component.controller','falcon.label']);

    function CheckboxController($scope, $controller,$element,$compile)
    {
        angular.extend(this, $controller('falconBaseComponentController', {$scope: $scope}));

        // default values
        var checkboxClass = 'input-jpmm';
        var labelObj = '';

        // if we are attaching a label to the dropdown, we need to add the label as
        // well as update the class definition accordingly
        if ( angular.isDefined($scope.labelName) )
        {
            checkboxClass = checkboxClass + ' form-control';
            labelObj = '<falcon-label-form label-align="{{labelAlign}}" value="{{labelName}}"></falcon-label-form>';
        }

        this.initTemplate($scope,$element,$compile, labelObj, checkboxClass);
    }

    CheckboxController.prototype.initTemplate= function($scope,$element,$compile,labelObj,checkboxClass)
    {
        var checkboxTemplate = '<div class="col-sm-{{width}} col-md-{{width}} col-lg-{{width}} form-group" '+
            'id="{{id}}"> ' +
            labelObj +
            '<input class="' + checkboxClass + '" ' +
            'type="checkbox" ' +
            'ng-model="checkboxValue" ' +
            'ng-change="checkboxChange()"'+
            'ng-disabled="disable" >  '+
            '</input></div>';

        $compile($element.html(checkboxTemplate).contents())($scope);
    }

    app.directive('falconCheckbox', function ()
    {
        return {
            restrict: 'E',
            controller: CheckboxController,
            controllerAs: 'cController',
            scope:
            {
                id: "@",
                disable: "=?",
                visible: "=?",
                mandatory: "=?",
                checkboxValue: "=",
                labelName: "@",
                labelAlign: "@",
                width: "@",
                checkboxChange: "&"
            },
            link : function($scope, $element, attr, ctrl)
            {
                if (attr.hasOwnProperty("visible"))
                {
                    function display()
                    {
                        if ($scope.visible === true)
                        {
                            $element.show();
                        }
                        else if($scope.visible === false)
                        {
                            $element.hide();
                        }
                    }
                    $scope.$watch("visible", display);
                    setTimeout(display, 0);
                }
            }
        };
    });
}());
