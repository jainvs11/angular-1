/**
 * Created by N591450 on 3/30/2016.
 */

/// <reference path="../../../../../typings/angularjs/angular.d.ts" />
/// <reference path="../common/UserInterfaceDto"/>
/// <reference path="../proxyService/proxyService"/>
/// <reference path="../common/ComponentScope"/>

namespace RuleServiceModule
{
    export class RuleService
    {
        static $inject = ['$rootScope'];
        public proxyService:ProxyServiceModule.ProxyService;

        constructor(private $rootScope:ng.IRootScopeService)
        {
            var test:string = "Vikas1";
        }

        public callRulesServer = () =>
        {
            var serverResponse = this.proxyService.callServer()
                .then((response)=>
                {
                    this.applyRules(response);
                },
                function (data)
                {
                    console.log('data retrieval failed.')
                });
            //this.applyRules(jQuery.parseJSON( serverResponse ));
        }

        public  init = (proxySer:ProxyServiceModule.ProxyService) =>
        {
            this.proxyService = proxySer;
            this.$rootScope.$on('get_ui_rules', () =>
            {
                this.callRulesServer();

            });

        }

        public applyRules = (lstUserInterface:Array<Common.UserInterfaceDto>) =>
        {
            for (var iUIDto = 0; iUIDto < lstUserInterface.length; iUIDto++)
            {
                var uIDto:Common.UserInterfaceDto = lstUserInterface[iUIDto];
                var elementId:string = '#' + uIDto.resourceId;
                //angular.element(elementId).isolateScope().applyRules(uIDto);
                var cusScope:Common.ComponentScope = <Common.ComponentScope>angular.element(elementId).isolateScope();
                cusScope.applyRules(uIDto);
            }
        }

    }
}
