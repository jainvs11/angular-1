/**
 * Created by F539408 on 4/11/2016.
 */

/// <reference path="./IProgressBarScope" />
/// <reference path="../common/ComponentController" />

namespace CustomProgressBar
{
    export class ProgressBarController extends Common.ComponentController
    {
        static $inject = [
            "$scope"
        ];

        constructor(public progressBarScope:CustomProgressBar.IProgressBarScope)
        {
            super( progressBarScope );
        }

        getPercentage = function ()
        {
            return ((this.current * 100) / this.total).toFixed(2);
        }
    }
}
