/**
 * Created by V559853 on 5/1/2016.
 */

/// <reference path="../common/ComponentScope"/>

namespace CustomProgressBar
{
    export interface IProgressBarScope extends Common.ComponentScope
    {
        total:number ;
        current:number  ;
        progressCompleted : any;
    }
}