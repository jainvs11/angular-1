/**
 * Created by F539408 on 4/11/2016.
 */

/// <reference path="../../../../../typings/angularjs/angular.d.ts" />
/// <reference path="./CustomProgressBarController"/>
/// <reference path="./IProgressBarScope"/>

namespace CustomProgressBar
{
    export class ProgressBarDirective implements ng.IDirective
    {
        public restrict: string     = "E";
        public controller: Function = CustomProgressBar.ProgressBarController;
        public controllerAs: string = 'cpbController';
        public replace: boolean = true;
        public scope: any           = {
            id: "@",
            total: "=",
            current: "=",
            progressCompleted: "="
        };
        public template: string     =   '<div \
                                            id="{{id}}" \
                                            class="progress" \
                                            style="width: 0%;"> \
                                            <div \
                                                id="activeProgress" \
                                                class="progress-bar progress-bar-success progress-bar-striped " \
                                                role="progressbar active" \
                                                aria-valuenow="10" \
                                                aria-valuemin="0" \
                                                aria-valuemax="100" \
                                                total="total" \
                                                current="current" > \
                                                <span \
                                                    class="jpmm" \
                                                    id="progressText" \
                                                    class="jpmm-bold" > \
                                                </span> \
                                            </div> \
                                         </div>';

        public link: (progressBarScope: IProgressBarScope,
                      element: ng.IAugmentedJQuery,
                      attrs: ng.IAttributes) => void;

        constructor()
        {
            this.link = (progressBarScope: IProgressBarScope,
                         element: ng.IAugmentedJQuery,
                         attrs: ng.IAttributes) =>
            {
                var cmpl = $('#progressText');
                var ariaEl = $('#activeProgress');
                progressBarScope.$watch("current", function (value)
                {
                    let procentage:number;
                    procentage = (progressBarScope.current / progressBarScope.total * 100);
                    if (procentage > 100)
                    {
                        procentage = 100;
                    }
                    var procText = procentage.toFixed(0);
                    ariaEl.attr('aria-valuenow', procText);
                    element.css("width", procText + "%");
                    cmpl.text(procText + "%");
                });
                progressBarScope.$watch("total", function (value)
                {
                    let procentage:number;
                    procentage = (progressBarScope.current / progressBarScope.total * 100);
                    if (procentage > 100)
                    {
                        procentage = 100;
                    }
                    var procText = procentage.toFixed(0);
                    ariaEl.attr('aria-valuenow', procText);
                    element.css("width", procText + "%");
                    cmpl.text(procText + "%");
                })
            };
        }

        public static Factory()
        {
            return new CustomProgressBar.ProgressBarDirective();
        }
    }
}

