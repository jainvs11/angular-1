
/// <reference path="./IPanelScope" />
/// <reference path="../common/ComponentController" />

namespace CustomPanel
{
    export class PanelController extends Common.ComponentController
    {
        static $inject = [
            "$scope"
        ];

        constructor(public panelScope:CustomPanel.IPanelScope)
        {
            super( panelScope );
        }
    }
}
