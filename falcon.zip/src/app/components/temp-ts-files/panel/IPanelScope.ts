/**
 * Created by V559853 on 4/29/2016.
 */

/// <reference path="../common/ComponentScope"/>

namespace CustomPanel
{
    export interface IPanelScope extends Common.ComponentScope
    {
        title:string;
        isOpen:boolean;
    }
}