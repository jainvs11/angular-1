
/// <reference path="../../../../../typings/angularjs/angular.d.ts" />
/// <reference path="./CustomPanelController"/>
/// <reference path="./IPanelScope" />

namespace CustomPanel
{
    export class PanelDirective implements ng.IDirective
    {
        public restrict: string     = "E";
        public controller: Function = CustomPanel.PanelController;
        public controllerAs: string = 'pController';
        public replace: boolean     = true;
        public transclude:boolean   = true;
        public scope: any           = {
            id: "@",
            title: "@",
            isOpen: "="
        };
        public template: string     =   '<div \
                                            id="{{id}}" \
                                            class="panel panel-default"> \
                                            <div \
                                                class="panel-heading">\
                                                <h4 \
                                                    class="panel-title">\
                                                    <a \
                                                        ng-click="isOpen=!isOpen"> \
                                                        <b> \
                                                            {{isOpen?"&#45;":"&#43;"}} \
                                                        </b> \
                                                    </a> &nbsp;&nbsp;&nbsp;&nbsp; \
                                                    {{title}} \
                                                </h4> \
                                            </div> \
                                            <div \
                                                class="panel-body" \
                                                ng-show="isOpen" \
                                                ng-transclude>\
                                            </div> \
                                         </div>';

        public link: (panelScope: IPanelScope,
                      element: ng.IAugmentedJQuery,
                      attrs: ng.IAttributes) => void;

        constructor()
        {
            this.link = (panelScope: IPanelScope,
                         element: ng.IAugmentedJQuery,
                         attrs: ng.IAttributes) =>
            {
                //console.log(" Link Function of Panel Called");
            };
        }

        public static Factory()
        {
            return new CustomPanel.PanelDirective();
        }
    }
}
