/**
 * Created by F539408 on 3/10/2016.
 */

/// <reference path="./ICheckBoxScope"/>
/// <reference path="../common/ComponentController"/>

namespace CustomCheckbox
{
    export class CheckboxController extends Common.ComponentController
    {
        static $inject = [
            "$scope"
        ];

        constructor(public checkboxScope:CustomCheckbox.ICheckBoxScope)
        {
            super( checkboxScope );
        }

        onChange = ()=>
        {
            this.$scope.$emit('get_ui_rules', {resourceId: this.$scope.id});
        }
    }
}