/**
 * Created by N591450 on 3/30/2016.
 */

/// <reference path="../common/ComponentScope"/>

namespace CustomCheckbox
{
    export interface ICheckBoxScope extends Common.ComponentScope
    {
        item:string;
        checkboxValue:string;
    }
}
