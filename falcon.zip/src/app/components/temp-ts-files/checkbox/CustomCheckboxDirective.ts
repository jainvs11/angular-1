/**
 * Created by F539408 on 3/10/2016.
 */

/// <reference path="../../../../../typings/angularjs/angular.d.ts" />
/// <reference path="./CustomCheckboxController"/>
/// <reference path="./ICheckBoxScope"/>

namespace CustomCheckbox
{
    export class CheckboxDirective implements ng.IDirective
    {
        public restrict: string     = "E";
        public controller: Function = CustomCheckbox.CheckboxController;
        public controllerAs: string = 'cController';
        public replace: boolean     = true;
        public scope: any           = {
                                        id: "@",
                                        item: "=",
                                        checkboxValue: "="
                                      };
        public template: string     =   '<div \
                                            ng-show="visible" \
                                            class="jpmm" > \
                                            <label> \
                                                {{item}} \
                                            </label>  \
                                            <input \
                                                id="{{id}}" \
                                                type="checkbox" \
                                                ng-change="cController.onChange()" \
                                                class="jpmm-checkbox" \
                                                ng-model="checkboxValue" \
                                            /> \
                                        </div>';

        public link: (checkboxScope: ICheckBoxScope,
                      element: ng.IAugmentedJQuery,
                      attrs: ng.IAttributes) => void;

        constructor()
        {
            this.link = (checkboxScope: ICheckBoxScope,
                         element: ng.IAugmentedJQuery,
                         attrs: ng.IAttributes) =>
            {
                //console.log(" Link Function of Checkbox Called");
            };
        }

        public static Factory()
        {
            return new CustomCheckbox.CheckboxDirective();
        }
    }
}
