/**
 * Created by F539408 on 3/24/2016.
 */

/// <reference path="../../../../../typings/angularjs/angular.d.ts" />
/// <reference path="./IFileUploadScope" />
/// <reference path="../common/ComponentController" />

namespace CustomFileUpload
{
    export class FileUploadController extends Common.ComponentController
    {
        element:ng.IAugmentedJQuery;
        scope:CustomFileUpload.IFileUploadScope;

        static $inject = [
            "$scope"
        ];

        constructor(public fileUploadScope:CustomFileUpload.IFileUploadScope)
        {
            super( fileUploadScope );
            this.scope = fileUploadScope;
            this.scope.addChangeListener = this.addChangeListener;
        }

        fileSelected = function():void
        {
            this.scope.fileModel = this.element.children[0].files[0];
        }

        addChangeListener = function(element:ng.IAugmentedJQuery):void
        {
            this.element = element;
            this.element.bind('change', this.fileSelected);
        }
    }
}
