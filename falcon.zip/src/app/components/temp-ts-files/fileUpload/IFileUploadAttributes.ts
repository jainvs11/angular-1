/**
 * Created by V559853 on 4/30/2016.
 */

/// <reference path="../../../../../typings/angularjs/angular.d.ts" />

namespace CustomFileUpload
{
    export interface IFileUploadAttributes extends ng.IAttributes
    {
        fileModel:any;
    }
}