/**
 * Created by V559853 on 4/30/2016.
 */

/// <reference path="../../../../../typings/angularjs/angular.d.ts" />
/// <reference path="../common/ComponentScope"/>

namespace CustomFileUpload
{
    export interface IFileUploadScope extends Common.ComponentScope
    {
        fileModel :any;
        addChangeListener(element:ng.IAugmentedJQuery):void;
    }
}