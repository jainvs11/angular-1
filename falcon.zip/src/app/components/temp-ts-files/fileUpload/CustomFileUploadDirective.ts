/**
 * Created by F539408 on 3/24/2016.
 */

/// <reference path="../../../../../typings/angularjs/angular.d.ts" />
/// <reference path="./CustomFileUploadController"/>

namespace CustomFileUpload
{
    export class FileUploadDirective implements ng.IDirective
    {
        public restrict: string     = "E";
        public controller: Function = CustomFileUpload.FileUploadController;
        public controllerAs: string = 'fuController';
        public replace:boolean      = true;
        public scope: any           = {
            id: "@",
            fileModel: "="
        };
        public template: string     =   '<input \
                                            id="{{id}}" \
                                            class="jpmm" \
                                            type="file" \
                                         />';

        public link: (fileUploadScope: CustomFileUpload.IFileUploadScope,
                      element: ng.IAugmentedJQuery,
                      attrs: ng.IAttributes) => void;

        constructor()
        {
            this.link = (fileUploadScope: CustomFileUpload.IFileUploadScope,
                         element: ng.IAugmentedJQuery,
                         attrs: ng.IAttributes) =>
            {
                fileUploadScope.addChangeListener(element);
            };
        }

        public static Factory()
        {
            return new CustomFileUpload.FileUploadDirective();
        }
    }
}
