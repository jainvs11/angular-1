/**
 * Created by V559853 on 5/2/2016.
 */

/// <reference path="../../../../../typings/angularjs/angular.d.ts" />
/// <reference path="./CustomSpinnerController"/>
/// <reference path="./ISpinnerScope"/>

namespace CustomSpinner
{
    export class SpinnerMediumDirective implements ng.IDirective
    {
        public restrict:string = "E";
        public controller:Function = CustomSpinner.SpinnerController;
        public controllerAs:string = 'sController';
        public replace:boolean = true;
        public transclude:boolean = true;
        public scope:any = {
            id: "@"
        };
        public template:string =    '<div \
                                        class="example-spinner-wrapper circular-spinner gpu" \
                                        style="float: left;"> \
                                     </div>';

        public link:(spinnerScope:ISpinnerScope,
                     element:ng.IAugmentedJQuery,
                     attrs:ng.IAttributes) => void;

        constructor()
        {
            this.link = (spinnerScope:ISpinnerScope,
                         element:ng.IAugmentedJQuery,
                         attrs:ng.IAttributes) =>
            {
                //console.log(" Link Function of Spinner Medium Called");
            };
        }

        public static Factory()
        {
            return new CustomSpinner.SpinnerMediumDirective();
        }
    }
}
