/**
 * Created by V559853 on 5/2/2016.
 */

/// <reference path="./ISpinnerScope" />
/// <reference path="../common/ComponentController" />

namespace CustomSpinner
{
    export class SpinnerController extends Common.ComponentController
    {
        static $inject = [
            "$scope"
        ];

        constructor(public spinnerScope:CustomSpinner.ISpinnerScope)
        {
            super( spinnerScope );
        }
    }
}