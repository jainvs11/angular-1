/**
 * Created by V559853 on 4/30/2016.
 */


namespace CustomMenu
{
    export class Menu
    {
        id :number;
        name : string;
        href : string;
        active : boolean;
        action : any;
        children : Menu;
    }
}