/**
 * Created by F539408 on 3/31/2016.
 */

/// <reference path="../../../../../typings/angularjs/angular.d.ts" />
/// <reference path="./CustomMenuController"/>
/// <reference path="./IMenuScope"/>
/// <reference path="./Menu"/>

namespace CustomMenu
{
    export class HorizontalMenuDirective implements ng.IDirective
    {
        public restrict: string     = "E";
        public controller: Function = CustomMenu.HMenuController;
        public controllerAs: string = 'hmController';
        public replace: boolean = false;
        public scope: any           = {
            id: "@",
            menuItems: "="
        };

        // TODO - need to add recursion to the building of this TEMPLATE
        public template: string     =   '<nav id="theme-nav" class="navbar nav-pills" role="navigation" \
                                            style="background: #bbbbbb; margin-bottom: 0px; border-radius : 0px;" > \
                                            <div class="container" > \
                                            <div class="navbar-header" > \
                                            <ul id="{{id}}" class="nav navbar-nav " ng-repeat="item in menuItems" > \
                                            <li  class="menu-item" ng-class="{dropdown: item.children}"   > \
                                            <a ng-if="item.active" href="{{item.href}}" class="{dropdown-toggle : item.children}" data-toggle="dropdown"   \
                                            role="button" aria-haspopup="true" aria-expanded="false" ng-click="hmController.addTab(item)" >{{item.name}}<span ng-if="item.children" class="caret"></span></a> \
                                            <a ng-if="!item.active" href="{{item.href}}" class="{dropdown-toggle : item.children}" data-toggle="dropdown"   \
                                            role="button" aria-haspopup="true" aria-expanded="false"  >{{item.name}}<span ng-if="item.children" class="caret"></span></a> \
                                            <ul  ng-if="item.children" class="dropdown-menu"   > \
                                            <li ng-repeat="child in item.children" class="active dropdown" ng-class=" {\'dropdown-submenu\' : child.children}"    > \
                                            <a ng-if="child.active" class="menu-item" ng-class="{ \'dropdown-toggle\' : child.children}" data-toggle="dropdown "  \
                                            href="{{child.href}}" ng-click="hmController.addTab( child)" >{{child.name}}</a> \
                                            <a ng-if="!child.active"  class="menu-item" ng-class="{ \'dropdown-toggle\' : child.children}" data-toggle="dropdown "  \
                                            href="{{child.href}}">{{child.name}}</a> \
                                            <ul ng-if="child.children" class="dropdown-menu"  > \
                                            <li ng-repeat="gchild in child.children" class="active dropdown" ng-class=" {\'dropdown-submenu\' : gchild.children}"  > \
                                            <a ng-if="gchild.active" class="menu-item" ng-class="{ \'dropdown-toggle\' : gchild.children}" data-toggle="dropdown " \
                                            href="{{gchild.href}}" ng-click="hmController.addTab( gchild)" >{{gchild.name}}</a> \
                                            <a ng-if="!gchild.active" class="menu-item" ng-class="{ \'dropdown-toggle\' : gchild.children}" data-toggle="dropdown " \
                                            href="{{gchild.href}}">{{gchild.name}}</a> \
                                            <ul ng-if="gchild.children" class="dropdown-menu"  > \
                                            <li ng-repeat="ggchild in gchild.children" class="active dropdown" ng-class=" {\'dropdown-submenu\' : ggchild.children}" > \
                                            <a ng-if="ggchild.active"  class="menu-item" ng-class="{ \'dropdown-toggle\' : ggchild.children}" data-toggle="dropdown " \
                                            href="{{ggchild.href}}" ng-click="hmController.addTab(ggchild)">{{ggchild.name}}</a> \
                                            <a ng-if="!ggchild.active"  class="menu-item" ng-class="{ \'dropdown-toggle\' : ggchild.children}" data-toggle="dropdown " \
                                            href="{{ggchild.href}}">{{ggchild.name}}</a> \
                                            <ul ng-if="ggchild.children" class="dropdown-menu"  > \
                                            <li ng-repeat="gggchild in ggchild.children" class="active dropdown" ng-class=" {\'dropdown-submenu\' : gggchild.children}" > \
                                            <a ng-if="gggchild.active" class="menu-item" ng-class="{ \'dropdown-toggle\' : gggchild.children}" data-toggle="dropdown " \
                                            href="{{gggchild.href}}" ng-click="hmController.addTab( gggchild)" >{{gggchild.name}}</a> \
                                            <a ng-if="!gggchild.active" class="menu-item" ng-class="{ \'dropdown-toggle\' : gggchild.children}" data-toggle="dropdown " \
                                            href="{{gggchild.href}}">{{gggchild.name}}</a> \
                                            <ul ng-if="gggchild.children" class="dropdown-menu"  > \
                                            <li ng-repeat="ggggchild in gggchild.children" class="active dropdown" ng-class=" {\'dropdown-submenu\' : ggggchild.children}" > \
                                            <a ng-if="ggggchild.active" class="menu-item" ng-class="{ \'dropdown-toggle\' : ggggchild.children}" data-toggle="dropdown " \
                                            href="{{ggggchild.href}}" ng-click="hmController.addTab( ggggchild)">{{ggggchild.name}}</a> \
                                            <a ng-if="!ggggchild.active" class="menu-item" ng-class="{ \'dropdown-toggle\' : ggggchild.children}" data-toggle="dropdown " \
                                            href="{{ggggchild.href}}">{{ggggchild.name}}</a> \
                                            </li> \
                                            </ul> \
                                            </li> \
                                            </ul> \
                                            </li> \
                                            </ul> \
                                            </li> \
                                            </ul> \
                                            </li> \
                                            </ul> \
                                            </li> \
                                            </ul> \
                                            </div> \
                                            </div> \
                                            </nav>';

        public link: (menuScope: IMenuScope,
                      element: ng.IAugmentedJQuery,
                      attrs: ng.IAttributes) => void;

        constructor()
        {
            this.link = (menuScope: IMenuScope,
                         element: ng.IAugmentedJQuery,
                         attrs: ng.IAttributes) =>
            {
                //console.log(" Link Function of HMenu Called");
            };
        }

        public static Factory()
        {
            return new CustomMenu.HorizontalMenuDirective();
        }
    }

    export class ParentMenuDirective implements ng.IDirective
    {
        public restrict: string     = "E";
        public controller: Function = CustomMenu.ParentController;
        public controllerAs: string = 'pmController';
        public replace: boolean = false;
        public scope: any           = {
            id: "@",
            menuItems: "="
        };
        public template: string     =   '<nav \
                                            id="theme-nav" \
                                            class="navbar nav-pills" \
                                            role="navigation" \
                                            style="background: #bbbbbb; margin-bottom: 0px; border-radius : 0px;" > \
                                            <div \
                                                class="container" > \
                                                <div \
                                                    class="navbar-header" > \
                                                        <ul \
                                                            id="{{id}}" \
                                                            class="nav navbar-nav" \
                                                            ng-repeat="item in menuItems" > \
                                                            <li \
                                                                class="menu-item" \
                                                                ng-class="{dropdown: item.children}"> \
                                                                <a \
                                                                    ng-if="item.active" \
                                                                    href="{{item.href}}" \
                                                                    class="{dropdown-toggle : item.children}" \
                                                                    data-toggle="dropdown" \
                                                                    role="button" \
                                                                    aria-haspopup="true" \
                                                                    aria-expanded="false" \
                                                                    ng-click="pmController.addTab(item)" >\
                                                                    {{item.name}}\
                                                                    <span \
                                                                        ng-if="item.children" \
                                                                        class="caret">\
                                                                    </span>\
                                                                </a> \
                                                                <a \
                                                                    ng-if="!item.active" \
                                                                    href="{{item.href}}" \
                                                                    class="{dropdown-toggle : item.children}" \
                                                                    data-toggle="dropdown"   \
                                                                    role="button" \
                                                                    aria-haspopup="true" \
                                                                    aria-expanded="false">\
                                                                    {{item.name}}\
                                                                    <span \
                                                                        ng-if="item.children" \
                                                                        class="caret">\
                                                                    </span>\
                                                                </a> \
                                                                <ul\
                                                                    ng-if="item.children" \
                                                                    class="dropdown-menu" \
                                                                    ng-include="\'menutemplate.html\'"> \
                                                                </ul> \
                                                            </li> \
                                                        </ul> \
                                                    </div> \
                                                </div> \
                                            </nav>';

        public link: (menuScope: IMenuScope,
                      element: ng.IAugmentedJQuery,
                      attrs: ng.IAttributes) => void;

        constructor()
        {
            this.link = (menuScope: IMenuScope,
                         element: ng.IAugmentedJQuery,
                         attrs: ng.IAttributes) =>
            {
                //console.log(" Link Function of ParentMenu Called");
            };
        }

        public static Factory()
        {
            return new CustomMenu.ParentMenuDirective();
        }
    }
}
