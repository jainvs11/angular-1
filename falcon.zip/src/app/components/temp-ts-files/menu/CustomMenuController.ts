/**
 * Created by F539408 on 3/31/2016.
 */

/// <reference path="../common/ComponentController"/>
/// <reference path="./IMenuScope"/>
/// <reference path="./Menu"/>

namespace CustomMenu
{
    export class HMenuController extends Common.ComponentController
    {
        hMenuScope:CustomMenu.IMenuScope;

        static $inject = [
            "$scope"
        ];

        constructor(public menuScope:CustomMenu.IMenuScope)
        {
            super( menuScope );
            this.hMenuScope = menuScope;
        }

        addTab = function (data)
        {
            console.log("addTab function in controller was called " + data.name);
            this.hMenuScope.$emit('menuEvent', data);
        }
    }

    export class ParentController extends Common.ComponentController
    {
        parentMenuScope:CustomMenu.IMenuScope;

        static $inject = [
            "$scope"
        ];

        constructor(public menuScope:CustomMenu.IMenuScope)
        {
            super( menuScope );
            this.parentMenuScope = menuScope;
            this.parentMenuScope.items = this.createItemsArray();
        }

        createItemsArray = function ()
        {
            var flat = [];
            for (var i = 0; i < this.menuItems.length; i++)
            {
                if (this.menuItems[i] instanceof Array)
                {
                    flat.push.apply(flat, this.createItemsArray.apply(this, this.menuItems[i]));
                }
                else
                {
                    flat.push(this.menuItems[i]);
                }

                var children = this.menuItems[i].children;
                if (children != undefined)
                {
                    for (var j = 0; j < children.length; j++)
                    {
                        if (this.menuItems[j] instanceof Array)
                        {
                            flat.push.apply(flat, this.createItemsArray.apply(this, this.menuItems[j]));
                        }
                        else
                        {
                            flat.push(this.menuItems[j]);
                        }
                    }
                }
            }
            return flat;
        }

        addTab = function (data)
        {
            console.log("addTab function in parent controller was called " + data.name);
            this.parentMenuScope.$emit('menuEvent', data);
        }
    }
}

