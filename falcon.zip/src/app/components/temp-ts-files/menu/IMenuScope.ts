/**
 * Created by V559853 on 4/30/2016.
 */

/// <reference path="../common/ComponentScope"/>
/// <reference path="./Menu"/>

namespace CustomMenu
{
    export interface IMenuScope extends Common.ComponentScope
    {
        id:string;
        items : Menu [];
        menuItems: Menu[];
    }
}