/**
 * Created by F539408 on 3/9/2016.
 */

/// <reference path="../../../../../typings/angularjs/angular.d.ts" />

namespace ProxyServiceModule
{
    export class ProxyService
    {
        static $inject = [
            "$http", "$q"
        ];
        public serverURL:string = "";

        constructor(private $http:ng.IHttpService,
                    private $q:ng.IQService)
        {
        }

        public  init = (url:string) =>
        {

            this.serverURL = url;

            console.log("test thisssss --->" + this.serverURL)
        }

        public callServer = ():any =>
        {
            var def = this.$q.defer();
            var parameters = '{"moduleId":"ACCE","inputDTO":null,"teamDTO":null}';

            var config:angular.IRequestShortcutConfig = {
                headers: {
                    'Content-Type': 'application/json'
                }
            }
            this.$http.post(this.serverURL, parameters, config).success(function (data)
            {
                //service.albums = data;
                def.resolve(data);
            }).error(function ()
            {
                def.reject("Failed to get Data");
            });

            return def.promise;
        }

        public callServerWithArgs =(serviceName:string, parameters:any): any =>
        {
            var def = this.$q.defer();

            var config: angular.IRequestShortcutConfig = {
                headers: {
                    'Content-Type': 'application/json'
    }
            }
            this.$http.post(this.serverURL+serviceName, parameters, config).success(function(data) {
                //service.albums = data;
                def.resolve(data);
            }).error(function() {
                def.reject("Failed to get Data");
            });

            return def.promise;
        }


    }
    //angular.module('proxyModule'[]).service['proxyService']
}
