/**
 * Created by F539408 on 4/4/2016.
 */

/// <reference path="./ITreeScope" />
/// <reference path="../common/ComponentController" />

namespace CustomTree
{
    export class TreeController extends Common.ComponentController
    {
        static $inject = [
            "$scope"
        ];

        constructor(public treeScope:CustomTree.ITreeScope)
        {
            super( treeScope );
        }
    }
}


