/**
 * Created by F539408 on 4/4/2016.
 */

/// <reference path="../../../../../typings/angularjs/angular.d.ts" />
/// <reference path="./CustomTreeController"/>
/// <reference path="./ITreeScope"/>

namespace CustomTree
{
    export class TreeDirective implements ng.IDirective
    {
        public restrict: string     = "E";
        public controller: Function = CustomTree.TreeController;
        public controllerAs: string = 'ntmController';
        public scope: any           = {
            id: "@",
            launcherOptions: "=",
            selectedNodes: "=?"
        };
        public template: string     =   '<treecontrol \
                                            id="{{id}}" \
                                            class="tree-light" \
                                            tree-model="launcherOptions" \
                                            selected-nodes="selectedNodes" \
                                            on-selection="showSelected(node, selected)" > \
                                            {{node.name}} \
                                         </treecontrol>';

        public link: (treeScope: ITreeScope,
                      element: ng.IAugmentedJQuery,
                      attrs: ng.IAttributes) => void;

        constructor()
        {
            this.link = (treeScope: ITreeScope,
                         element: ng.IAugmentedJQuery,
                         attrs: ng.IAttributes) =>
            {
                //console.log(" Link Function of Tree Called");
            };
        }

        public static Factory()
        {
            return new CustomTree.TreeDirective();
        }
    }
}

