/**
 * Created by V559853 on 5/1/2016.
 */

/// <reference path="../common/ComponentScope"/>
/// <reference path="./CustomTree"/>

namespace CustomTree
{
    export interface ITreeScope extends Common.ComponentScope
    {
        launcherOptions:Tree[];
        selectedNodes:Tree[];
    }
}
