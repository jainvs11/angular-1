/**
 * Created by V559853 on 5/1/2016.
 */

namespace CustomTree
{
    export class Tree
    {
        label : string;
        url : string;
        style : boolean;
        children : Tree;
    }
}