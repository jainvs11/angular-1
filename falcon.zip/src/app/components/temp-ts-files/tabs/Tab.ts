/**
 * Created by V559853 on 5/2/2016.
 */

namespace CustomTab
{
    export class Tab
    {
        title : string;
        selected : boolean;
    }
}