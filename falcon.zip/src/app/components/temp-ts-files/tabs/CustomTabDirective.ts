/**
 * Created by F539408 on 3/30/2016.
 */

/// <reference path="../../../../../typings/angularjs/angular.d.ts" />
/// <reference path="./CustomTabController"/>
/// <reference path="./ITabScope"/>

namespace CustomTab
{
    export class TabDirective implements ng.IDirective
    {
        // 'customTabs' is the name of the directive registered with Angular that it will inherit from,
        // which is defined in customComponents.ts
        public require:any = '^customTabs';
        public restrict:string = "E";
        public replace:boolean = true;
        public transclude:any = true;
        public scope:any = {
            id: "@",
            title: "@",
            selected: "=?"
        };
        public template:string =    '<div \
                                        class="tab-pane ul.nav.nav-tabs.sheet" \
                                        ng-class="{active: selected}" \
                                        ng-transclude> \
                                     </div>';

        public link:(tabScope:ITabScope,
                     element:ng.IAugmentedJQuery,
                     attrs:ng.IAttributes,
                     tController:TabsController) => void;

        constructor()
        {
            this.link = (tabScope:ITabScope,
                         element:ng.IAugmentedJQuery,
                         attrs:ng.IAttributes,
                         tController:TabsController) =>
            {
                tController.addTab(tabScope);
            };
        }

        public static Factory()
        {
            return new CustomTab.TabDirective();
        }
    }
}
