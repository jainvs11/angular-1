/**
 * Created by V559853 on 5/2/2016.
 */

/// <reference path="../common/ComponentScope"/>
/// <reference path="./Tab"/>

namespace CustomTab
{
    export interface ITabsScope extends Common.ComponentScope
    {
        tabs:Tab[];
    }
}