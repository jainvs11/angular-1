/**
 * Created by F539408 on 3/30/2016.
 */

/// <reference path="../../../../../typings/angularjs/angular.d.ts" />
/// <reference path="./CustomTabController"/>

namespace CustomTab
{
    export class TabsDirective implements ng.IDirective
    {
        public restrict:string = "E";
        public controller:Function = CustomTab.TabsController;
        public controllerAs:string = 'tabsController';
        public replace:boolean = true;
        public transclude:any = true;
        //TODO - not sure of binding type for 'tabs'
        public scope:any = {
            id: "@",
            tabs: "=?"
        };
        public template:string =    '<div \
                                        class="tabbable"> \
                                        <ul \
                                            class="nav nav-tabs "> \
                                            <li \
                                                ng-repeat="tab in tabs" \
                                                ng-class="{active : tab.selected}"> \
                                                <a \
                                                    href="" \
                                                    ng-click="tabsController.select(tab)">\
                                                    {{tab.title}}\
                                                </a> \
                                            </li> \
                                        </ul> \
                                        <div \
                                            class="tab-content" \
                                            ng-transclude>\
                                        </div> \
                                     </div>';

        public link:(tabScope:ITabsScope,
                     element:ng.IAugmentedJQuery,
                     attrs:ng.IAttributes) => void;

        constructor()
        {
            this.link = (tabScope:ITabsScope,
                         element:ng.IAugmentedJQuery,
                         attrs:ng.IAttributes) =>
            {
                //console.log(" Link Function of Tabs Called");
            };
        }

        public static Factory()
        {
            return new CustomTab.TabsDirective();
        }
    }
}
