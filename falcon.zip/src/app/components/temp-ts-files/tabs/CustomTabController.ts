/**
 * Created by F539408 on 3/30/2016.
 */

/// <reference path="./ITabsScope" />
/// <reference path="../common/ComponentController" />

namespace CustomTab
{
    export class TabsController extends Common.ComponentController
    {
        static $inject = [
            "$scope"
        ];

        constructor(public tabsScope:CustomTab.ITabsScope)
        {
            super(tabsScope);
            tabsScope.tabs = [];
        }

        addTab = function (tab:Tab)
        {
            if (this.tabsScope.tabs.length == 0)
            {
                this.select(tab);
            }

            this.tabsScope.tabs.push(tab);
        }

        select = function (tab:Tab)
        {
            angular.forEach(this.tabsScope.tabs, function (tab:Tab)
            {
                tab.selected = false;
            });
            tab.selected = true;
        }
    }
}