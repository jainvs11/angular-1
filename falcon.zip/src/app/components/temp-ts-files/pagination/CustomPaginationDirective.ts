/**
 * Created by F539408 on 4/8/2016.
 */

/// <reference path="../../../../../typings/angularjs/angular.d.ts" />
/// <reference path="./CustomPaginationController"/>
/// <reference path="./IPaginationScope"/>

namespace CustomPagination
{
    export class PaginationDirective implements ng.IDirective
    {
        public restrict: string     = "E";
        public controller: Function = CustomPagination.PaginationController;
        public controllerAs: string = 'pController';
        public replace: boolean     = true;
        public scope: any           = {
            id: "@",
            totalPages: "=",
            currentPage: "=",
            itemsPerPage: "=",
            pagesToShow: "="
        };
        public template: string     =   '<div \
                                            ng-show="true"> \
                                            <uib-pagination \
                                                direction-links="true" \
                                                boundary-link-numbers="true" \
                                                boundary-links="true" \
                                                force-ellipses="true" \
                                                previous-text="&lsaquo;" \
                                                next-text="&rsaquo;" \
                                                max-size="pagesToShow" \
                                                total-items="totalPages" \
                                                ng-model="currentPage" \
                                                items-per-page="itemsPerPage" > \
                                            </uib-pagination> \
                                        </div>';

        public link: (paginationScope: IPaginationScope,
                      element: ng.IAugmentedJQuery,
                      attrs: ng.IAttributes) => void;

        constructor()
        {
            this.link = (paginationScope: IPaginationScope,
                         element: ng.IAugmentedJQuery,
                         attrs: ng.IAttributes) =>
            {
                //console.log(" Link Function of Pagination Called");
            };
        }

        public static Factory()
        {
            return new CustomPagination.PaginationDirective();
        }
    }
}
