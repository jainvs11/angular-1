/**
 * Created by F539408 on 4/8/2016.
 */

/// <reference path="./IPaginationScope" />
/// <reference path="../common/ComponentController" />

namespace CustomPagination
{
    export class PaginationController extends Common.ComponentController
    {
        static $inject = [
            "$scope"
        ];

        constructor(public paginationScope:CustomPagination.IPaginationScope)
        {
            super( paginationScope );
        }
    }
}

