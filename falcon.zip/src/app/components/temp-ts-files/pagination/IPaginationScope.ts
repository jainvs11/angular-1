/**
 * Created by V559853 on 5/1/2016.
 */

/// <reference path="../common/ComponentScope"/>

namespace CustomPagination
{
    export interface IPaginationScope extends Common.ComponentScope
    {
        //TODO - not sure of TYPE for pagesToShow and number object or if they're needed
        totalPages:number;
        currentPage:number;
        itemsPerPage:number;
        pagesToShow;
        number;
    }
}
