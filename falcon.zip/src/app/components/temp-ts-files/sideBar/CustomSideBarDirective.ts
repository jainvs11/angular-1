
/// <reference path="../../../../../typings/angularjs/angular.d.ts" />
/// <reference path="./CustomSideBarController"/>
/// <reference path="./ISideBarScope"/>

namespace CustomSideBar
{
    export class SideBarDirective implements ng.IDirective
    {
        public restrict: string     = "E";
        public controller: Function = CustomSideBar.SideBarController;
        public controllerAs: string = 'sbController';
        public replace: boolean = true;
        public scope: any           = {
            id: "@",
            value: "=",
            state: "=?"
        };
        public template: string     =   '<div \
                                            id="{{id}}" \
                                            class="sidebar"> \
                                            <a \
                                                href="#" \
                                                id="navigation-toggle" \
                                                ng-click="sbController.toggleState()"> \
                                                Navigation \
                                            </a> \
                                            <ul \
                                                class="navigation"> \
                                                <li \
                                                    class="navigation-items">\
                                                    <a \
                                                        href="/">\
                                                        Link1\
                                                    </a> \
                                                </li> \
                                                <li \
                                                    class="navigation-items">\
                                                    <a \
                                                        href="/">\
                                                        Link2\
                                                    </a>\
                                                </li> \
                                            </ul>\
                                        </div>';

        public link: (sideBarScope: ISideBarScope,
                      element: ng.IAugmentedJQuery,
                      attrs: ng.IAttributes) => void;

        constructor()
        {
            this.link = (sideBarScope: ISideBarScope,
                         element: ng.IAugmentedJQuery,
                         attrs: ng.IAttributes) =>
            {
                sideBarScope.$watch(() => sideBarScope.state,
                    (newValue:boolean,
                     oldValue:boolean) =>
                    {
                        if (newValue)
                        {
                            element.addClass('show');
                            return;
                        }
                        element.removeClass('show');
                    });
            };
        }

        public static Factory()
        {
            return new CustomSideBar.SideBarDirective();
        }
    }
}
