/**
 * Created by V559853 on 5/1/2016.
 */

/// <reference path="../common/ComponentScope"/>

namespace CustomSideBar
{
    export interface ISideBarScope extends Common.ComponentScope
    {
        value:string;
        state:boolean;
    }
}