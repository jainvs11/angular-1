
/// <reference path="./ISideBarScope" />
/// <reference path="../common/ComponentController" />

namespace CustomSideBar
{
    export class SideBarController extends Common.ComponentController
    {
        scope:CustomSideBar.ISideBarScope;

        static $inject = [
            "$scope"
        ];

        constructor(public sideBarScope:CustomSideBar.ISideBarScope)
        {
            super( sideBarScope );
            sideBarScope.state = false;
            this.scope = sideBarScope;
        }

        toggleState = function ()
        {
            this.scope.state = !this.scope.state;
        };
    }
}
