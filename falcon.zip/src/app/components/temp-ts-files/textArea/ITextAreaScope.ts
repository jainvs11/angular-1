/**
 * Created by N591450 on 3/30/2016.
 */

/// <reference path="../common/ComponentScope"/>

namespace CustomTextArea
{
    export interface ITextAreaScope extends Common.ComponentScope
    {
        labelOfText:string;
        cols:string;
        rows:string;
    }
}
