/**
 * Created by F539408 on 3/23/2016.
 */

/// <reference path="./ITextAreaScope"/>
/// <reference path="../common/ComponentController"/>

namespace CustomTextArea
{
    export class TextAreaController extends Common.ComponentController
    {
        static $inject = [
            "$scope"
        ];

        constructor(public textAreaScope:CustomTextArea.ITextAreaScope)
        {
            super(textAreaScope);
        }

        public onBlur()
        {
            this.$scope.$emit('get_ui_rules', {resourceId: this.$scope.id});
        }
    }
}
