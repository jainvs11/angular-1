/**
 * Created by F539408 on 3/23/2016.
 */

/// <reference path="../../../../../typings/angularjs/angular.d.ts" />
/// <reference path="./CustomTextAreaController"/>
/// <reference path="./ITextAreaScope"/>

namespace CustomTextArea
{
    export class TextAreaDirective implements ng.IDirective
    {
        public restrict: string     = "E";
        public controller: Function = CustomTextArea.TextAreaController;
        public controllerAs: string = 'taController';
        public scope: any           = {
            id: "@",
            txtInput: "=",
            cols: "@",
            rows: "@"
        };
        public template: string     =   '<div \
                                            ng-show="visible"> \
                                            <textarea \
                                                d="{{id}}" \
                                                ng-model="txtInput" \
                                                cols="{{cols}}" \
                                                rows="{{rows}}" \
                                                ng-blur="taController.onBlur()"> \
                                            </textarea> \
                                         </div>';

        public link: (textAreaScope: CustomTextArea.ITextAreaScope,
                      element: ng.IAugmentedJQuery,
                      attrs: ng.IAttributes) => void;

        constructor()
        {
            this.link = (textAreaScope: CustomTextArea.ITextAreaScope,
                         element: ng.IAugmentedJQuery,
                         attrs: ng.IAttributes) =>
            {
                //console.log(" Link Function of TextArea Called");
            };
        }

        public static Factory()
        {
            return new CustomTextArea.TextAreaDirective();
        }
    }
}

