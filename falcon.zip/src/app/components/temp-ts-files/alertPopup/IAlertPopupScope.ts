/**
 * Created by V559853 on 4/30/2016.
 */

/// <reference path="../common/ComponentScope"/>

namespace CustomAlertPopup
{
    export interface IAlertPopupScope extends Common.ComponentScope
    {
        title:string;
    }
}

