/**
 * Created by F539408 on 4/8/2016.
 */

/// <reference path="../../../../../typings/angularjs/angular.d.ts" />
/// <reference path="./CustomAlertPopupController"/>
/// <reference path="./IAlertPopupScope"/>

namespace CustomAlertPopup
{
    export class AlertPopupDirective implements ng.IDirective
    {
        public restrict: string     = "E";
        public controller: Function = CustomAlertPopup.AlertPopupController;
        public controllerAs: string = 'apController';
        public replace: boolean     = true;
        public transclude: boolean  = true;
        public scope: any           = {
                                        id: "@",
                                        title: "@"
                                      };
        public template: string     =   '<div \
                                            class="modal fade" \
                                            id="{{id}}" \
                                            role="dialog"> \
                                            <div \
                                                class="modal-dialog"> \
                                                <div class="modal-content"> \
                                                    <div class="modal-header"> \
                                                        <button \
                                                            type="button" \
                                                            class="close" \
                                                            data-dismiss="modal" \
                                                            aria-hidden="true"> \
                                                            &times; \
                                                        </button> \
                                                        <h4 \
                                                            class="modal-title"> \
                                                            {{ title }} \
                                                        </h4> \
                                                    </div> \
                                                    <div \
                                                        class="modal-body" \
                                                        ng-transclude > \
                                                    </div> \
                                                </div> \
                                            </div> \
                                        </div>';

        public link: (alertPopupScope: IAlertPopupScope,
                      element: ng.IAugmentedJQuery,
                      attrs: ng.IAttributes) => void;

        constructor()
        {
            this.link = (alertPopupScope: IAlertPopupScope,
                         element: ng.IAugmentedJQuery,
                         attrs: ng.IAttributes) =>
            {
                //console.log(" Link Function of AlertPop Called");
            };
        }

        public static Factory()
        {
            return new CustomAlertPopup.AlertPopupDirective();
        }
    }
}