/**
 * Created by F539408 on 4/8/2016.
 */

/// <reference path="./IAlertPopupScope" />
/// <reference path="../common/ComponentController" />

namespace CustomAlertPopup
{
    export class AlertPopupController extends Common.ComponentController
    {
        static $inject = [
            "$scope"
        ];

        constructor(public alertPopupScope:CustomAlertPopup.IAlertPopupScope)
        {
            super( alertPopupScope );
        }
    }
}

