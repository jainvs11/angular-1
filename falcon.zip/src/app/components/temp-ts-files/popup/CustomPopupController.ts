
/// <reference path="../../../../../typings/angular-dialog-service/angular-dialog-service.d.ts" />
/// <reference path="../../../../../typings/ng-dialog/ng-dialog.d.ts" />
/// <reference path="./IPopupScope" />
/// <reference path="../common/ComponentController" />

namespace CustomPopup {
    export class PopupController extends Common.ComponentController {


        constructor(public popupScope:CustomPopup.IPopupScope,
                    public ngDialog:angular.dialog.IDialogService) {
            super(popupScope);
        }

        showPopup = (message:string, title:string, actionButtonName:string, closeButtonName:string, ngClass:string, actionEventName:string, data:any)=> {
            this.popupScope.actionEventName = actionEventName;
            this.popupScope.data = data;

            if (!ngClass || ngClass === "") {
                ngClass = 'ngdialog-theme-default';
            }
            this.ngDialog.open({
                template: '<div> \
                                     <h2>\
                                            ' + title + '\
                                        </h2>\
                                        ' + message + '\
                                        <br/>\
                                        <br/>\
                                        <input \
                                            type="button" \
                                            value="' + actionButtonName + '" \
                                            ng-click="pc.action()"\
                                        />\
                                        &nbsp;&nbsp;\
                                        <input \
                                            type="button" \
                                            value="' + closeButtonName + '" \
                                            ng-click="pc.customClose()"\
                                        />\
                                     </div>',
                plain: true,
                className: ngClass,
                closeByEscape: false,
                closeByDocument: false,
                controller: 'customPopupController',
                controllerAs: 'pc',
                scope: this.popupScope


            });
        }
        customClose = ()=> {
            this.ngDialog.close("", "No");
        }

        action = ()=> {
            this.popupScope.$emit(this.popupScope.actionEventName, this.popupScope.data);
            console.log("Event Emitted ::" + this.popupScope.actionEventName);
            this.ngDialog.close("", this.popupScope.actionEventName);
        }
        public static Factory($scope, ngDialog)
        {

            PopupController.Factory.$inject = ["$scope", "ngDialog"];
            return new CustomPopup.PopupController($scope, ngDialog);
        }
    }
}
