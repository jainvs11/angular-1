/**
 * Created by V559853 on 5/1/2016.
 */

/// <reference path="../common/ComponentScope"/>
/// <reference path="../../../../../typings/angularjs/angular.d.ts" />

namespace CustomPopup
{
    export interface IPopupScope extends Common.ComponentScope
    {
        data:any;
        message:string;
        title:string;
        actionButtonName:string;
        closeButtonName:string;
        ngClass:string;
        actionEventName:string;
    }
}