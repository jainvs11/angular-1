/**
 * Created by V559853 on 4/30/2016.
 */

/// <reference path="../common/ComponentScope"/>

namespace CustomMultiselectDropdown
{
    export interface IMultiselectDropdownScope extends Common.ComponentScope
    {
        multiselectData:Array<any>;
        selectedItem:any;
    }
}