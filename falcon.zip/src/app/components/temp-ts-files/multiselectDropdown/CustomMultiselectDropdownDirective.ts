/**
 * Created by F539408 on 4/5/2016.
 */

/// <reference path="../../../../../typings/angularjs/angular.d.ts" />
/// <reference path="./CustomMultiselectDropdownController"/>
/// <reference path="./IMultiselectDropdownScope"/>

namespace  CustomMultiselectDropdown
{
    export class MultiselectDropdownDirective implements ng.IDirective
    {
        public restrict: string     = "E";
        public controller: Function = CustomMultiselectDropdown.MultiselectDropdownController;
        public controllerAs: string = 'mdController';
        public scope: any           = {
            id: "@",
            multiselectData: "=",
            selectedItem: "="
        };

        // TODO - need to clean up the TEMPLATE to remove hardcoded values
        public template: string     =   '<ui-select \
                                            multiple \
                                            ng-model="selectedItem" \
                                            theme="bootstrap" \
                                            style="min-width: 300px;" \
                                            title="Choose a person"> \
                                            <ui-select-match \
                                                placeholder="Select a item in the list or search his name ..." \
                                                class="ui-select-match">\
                                                {{$item.name}}\
                                            </ui-select-match> \
                                            <ui-select-choices \
                                                repeat="selectedItem.name as selectedItem in multiselectData | filter: {name: $select.search, id: $select.search}" \
                                                class="ui-select-choices"> \
                                                <div \
                                                    ng-bind-html="selectedItem.name">\
                                                </div> \
                                            </ui-select-choices> \
                                        </ui-select>';

        public link: (multiselectScope: CustomMultiselectDropdown.IMultiselectDropdownScope,
                      element: ng.IAugmentedJQuery,
                      attrs: ng.IAttributes) => void;

        constructor()
        {
            this.link = (multiselectScope: CustomMultiselectDropdown.IMultiselectDropdownScope,
                         element: ng.IAugmentedJQuery,
                         attrs: ng.IAttributes) =>
            {
                //console.log(" Link Function of MultiSelectDropwn Called");
            };
        }

        public static Factory()
        {
            return new CustomMultiselectDropdown.MultiselectDropdownDirective();
        }
    }
}
