/**
 * Created by F539408 on 4/5/2016.
 */

/// <reference path="./IMultiselectDropdownScope" />
/// <reference path="../common/ComponentController" />

namespace CustomMultiselectDropdown
{
    export class MultiselectDropdownController extends Common.ComponentController
    {
        static $inject = [
            "$scope"
        ];

        constructor(public multiSelectScope:CustomMultiselectDropdown.IMultiselectDropdownScope)
        {
            super( multiSelectScope );
        }
    }
}