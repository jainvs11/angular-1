/**
 * Created by V559853 on 4/30/2016.
 */

namespace CustomDynamicTab
{
    export class DynamicTab
    {
        title : string;
        selected : boolean;
        content :any;
    }
}