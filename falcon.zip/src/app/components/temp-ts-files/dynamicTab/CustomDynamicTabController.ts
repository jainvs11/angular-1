/**
 * Created by F539408 on 3/30/2016.
 */

/// <reference path="../common/ComponentController" />
/// <reference path="./IDynamicTabScope"/>
/// <reference path="./DynamicTab"/>

namespace CustomDynamicTab
{
    export class DynamicTabController extends Common.ComponentController
    {
        static $inject = [
            "$scope"
        ];

        constructor(public tabScope:CustomDynamicTab.IDynamiceTabScope)
        {
            super( tabScope );
        }

        addTab = function (tab:CustomDynamicTab.DynamicTab)
        {
            if (this.tabs.length == 0)
            {
                this.select(tab);
            }
            this.tabs.push(tab);
        }

        select = function (tab:CustomDynamicTab.DynamicTab)
        {
            angular.forEach(this.tabs, function (tab:CustomDynamicTab.DynamicTab)
            {
                tab.selected = false;
            });
            tab.selected = true;
        }
    }
}
