/**
 * Created by F539408 on 3/30/2016.
 */

/// <reference path="../../../../../typings/angularjs/angular.d.ts" />
/// <reference path="./CustomDynamicTabController"/>
/// <reference path="./IDynamicTabScope"/>

namespace CustomDynamicTab
{
    export class DynamicTabDirective implements ng.IDirective
    {
        public restrict: string     = "E";
        public controller: Function = CustomDynamicTab.DynamicTabController;
        public controllerAs: string = 'dtController';
        public transclude: boolean  = true;
        public replace: boolean     = true;
        public scope: any           = {
                                        id: "@",
                                        tabs: "="
                                      };
        public template: string     =   '<div \
                                            class="tabbable" \
                                            id="{{id}}"> \
                                            <ul \
                                                class="nav nav-tabs "> \
                                                <li \
                                                    ng-repeat="tab in tabs" \
                                                    ng-class="{active : tab.selected}"> \
                                                    <a \
                                                        href="" \
                                                        ng-click="dtController.select(tab)">\
                                                        {{tab.title}}\
                                                    </a> \
                                                </li> \
                                            </ul> \
                                            <div \
                                                class="tab-content"> \
                                                <div \
                                                    ng-repeat="tab in tabs" \
                                                    class="tab-pane ul.nav.nav-tabs.sheet" \
                                                    ng-class="{active: tab.selected}"> \
                                                    <div \
                                                        ng-include="tab.content">\
                                                    </div> \
                                                </div> \
                                            </div> \
                                        </div>';

        public link: (tabScope: IDynamiceTabScope,
                      element: ng.IAugmentedJQuery,
                      attrs: ng.IAttributes) => void;

        constructor()
        {
            this.link = (tabScope: IDynamiceTabScope,
                         element: ng.IAugmentedJQuery,
                         attrs: ng.IAttributes) =>
            {
                //console.log(" Link Function of Tab Called");
            };
        }

        public static Factory()
        {
            return new CustomDynamicTab.DynamicTabDirective();
        }
    }
}
