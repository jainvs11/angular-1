/**
 * Created by V559853 on 4/30/2016.
 */

/// <reference path="../common/ComponentScope"/>
/// <reference path="./DynamicTab"/>

namespace CustomDynamicTab
{
    export interface IDynamiceTabScope extends Common.ComponentScope
    {
        tabs : DynamicTab[];
    }
}
