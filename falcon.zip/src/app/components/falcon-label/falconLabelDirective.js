(function() {

    var app = angular.module('falcon.label',['ui.bootstrap','falcon.base.component.controller']);

    function LabelController($scope, $controller,$element,$compile)
    {
        angular.extend(this, $controller('falconBaseComponentController', {$scope: $scope}));

        this.initTemplate($scope,$element,$compile);
    }

    LabelController.prototype.initTemplate= function($scope,$element,$compile)
    {
        // default values
        var labelObj = '';

        // if we are attaching a label to the dropdown, we need to add the label as
        // well as update the class definition accordingly
        if ( angular.isDefined($scope.labelName) )
        {
            labelObj = '<falcon-label-form label-align="{{labelAlign}}"></falcon-label-form>';
        }

        $compile($element.html(this.getTemplate($scope,labelObj)).contents())($scope);
    }

    LabelController.prototype.getTemplate = function($scope, labelObj)
    {
        var labelTemplate = '<div class="col-sm-{{width}} col-md-{{width}} col-lg-{{width}} form-group" '+
                                            'id="{{id}}"> ' +
                                            labelObj +
                                            '<label class="text-nowrap jpmm-label';
        if ( !$scope.labelAlign || $scope.labelAlign === 'top' ) {
            labelTemplate = labelTemplate + ' checkbox';    // TO-DO - HACK!!  Need to find out what to replace "checkbox" with!!!!!!!!!
        }

        labelTemplate = labelTemplate + '">{{value}}</label></div>';
        return labelTemplate;
    }

    // this directive is currently only used by other Falcon components to attach a label to it
    app.directive('falconLabelForm', function ($compile)
    {
        var getTemplate = function(labelName, labelAlign)
        {
            var labelTemplate = '<label class="text-nowrap jpmm-label';
            if ( angular.isUndefined(labelAlign) || labelAlign === "top" )
            {
                labelTemplate = labelTemplate + ' control-label';
            }

            labelTemplate = labelTemplate + '">{{labelName}}</label>';

            return labelTemplate;
        };

        return {
            restrict: 'E',
            scope: false,
            link: function(scope, element, attrs)
            {
                scope.$watch('mandatory', function()
                {
                    if ( scope.mandatory === true )
                    {
                        if (element.context.firstElementChild != undefined )
                        {
                            $(element.context.firstElementChild).addClass("mandatory-control");
                            $(element.context.firstElementChild).removeClass("control-label");
                        }
                    }
                    else
                    {
                        if (element.context.firstElementChild != undefined )
                        {
                            $(element.context.firstElementChild).removeClass("mandatory-control");
                        }
                    }
                });

                if (attrs.hasOwnProperty("visible"))
                {
                    function display()
                    {
                        if (scope.visible === true)
                        {
                            element.show();
                        }
                        else if($scope.visible === false)
                        {
                            element.hide();
                        }
                    }
                    scope.$watch("visible", display);
                    setTimeout(display, 0);
                }

                element.html(getTemplate(scope.labelName, scope.labelAlign)).show();
                $compile(element.contents())(scope);
            }
        };
    });

    app.directive('falconLabel', function ()
    {
        return {
            restrict: 'E',
            controller: LabelController,
            controllerAs: 'lController',
            scope:
            {
                id: "@",
                disable: "=?",
                visible: "=?",
                mandatory: "=?",
                value: "@",
                labelName: "@",
                labelAlign: "@",
                width: "@"
            },
            link : function($scope, $element, attr, ctrl)
            {
                if (attr.hasOwnProperty("visible"))
                {
                    function display()
                    {
                        if ($scope.visible === true)
                        {
                            $element.show();
                        }
                        else if($scope.visible === false)
                        {
                            $element.hide();
                        }
                    }
                    $scope.$watch("visible", display);
                    setTimeout(ngShow, 0);
                }
            }
        };
    });

}());
