(function() {
    var app = angular.module('falcon.leftnav',['ui.bootstrap', 'ui.bootstrap.tpls','falcon.base.component.controller']);
    
    function LeftNavController($scope, $controller,$element,$compile){
        angular.extend(this, $controller('falconBaseComponentController', {$scope: $scope}));
        $scope.appScope = $scope.appScope || $scope.$parent;
    };
   
    app.directive('falconNavmenu', function ()
    {
        return {
        	template:'<div class="mainMenu"><div class="list-group panel"><div ng-repeat="menuItemObj in inputModel"><a href="#{{menuItemObj.id}}"class="list-group-item list-group-item-success itemheader"data-toggle="collapse" data-parent="#mainMenu">{{menuItemObj.menuItem}}</a><div class="collapse in" id="{{menuItemObj.id}}"><a href="javascript:void(0);" ng-repeat="subMenuItemObj in menuItemObj.subMenuItems" ng-click="appScope.onClickMenuItem(menuItemObj.menuItem,subMenuItemObj.name)" class="list-group-item">{{subMenuItemObj.name}}</a></div></div></div></div>',
    		restrict : "E",
    		replace:true,
    		scope : {
    			inputModel: '='
    		},		
    		controller:LeftNavController,
    	    controllerAs: 'ctrl'
    	};
    });

}());
