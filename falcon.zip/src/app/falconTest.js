/**
 * Created by F539408 on 5/19/2016.
 */

const angular = require ('angular');
const jqueryui = require('jquery-ui');
const bootstrap =require('bootstrap');
const angularuibootstrap = require('ui-bootstrap');
const angularuibootstraptmpl = require('ui-bootstrap-tpls');
require('angular-route');
require('angular-ui-notification-js');
var testApp = angular.module("falconTestModule", [ 'ui.bootstrap','ngRoute', 'falcon']);

testApp.config(function ($routeProvider) {
    $routeProvider.
    when('/grid', {
        templateUrl: 'gridExample',
        controller: 'falconTestController'
    }).
    when('/button', {
        templateUrl: 'buttonExample',
        controller: 'falconTestController'
    }).
    when('/datepicker', {
        templateUrl: 'datepickerExample',
        controller: 'falconTestController'
    }).
    when('/accordion', {
        templateUrl: 'error.html',
    }).
    when('/dropdown', {
            templateUrl: 'dropdownExample',
            controller: 'falconTestController'
    }).
        when('/checkbox', {
            templateUrl: 'checkboxExample',
            controller: 'falconTestController'
        }).
    when('/input', {
            templateUrl: 'inputExample',
            controller: 'falconTestController'
    }).
    when('/label', {
    	templateUrl: 'labelExample',
        controller: 'falconTestController'
    }).
    when('/navmenu', {
    	templateUrl: 'navMenuExample',
        controller: 'falconTestController'
    }).
	 when('/notification', {
    	templateUrl: 'notification',
        controller: 'falconTestController'
    }).
    otherwise({
        redirectTo: '/grid'
    });
});

testApp.directive("codeSample", function() {
    return {
        transclude : true,
        restrict : "E",
        replace: true,
        template : '<div class="col-md-6 col-lg-6 ArticleCell"><code ng-transclude class="wordwrap"></code></div>'
    };
});

testApp.controller("falconTestController", function($scope,$timeout,uiGridConstants) {
    var vm = this;
	
	
	$scope.notifications = [{"id":7281,"sid":"U893286","message":"Request C26838 for GENEVA 8084 is awaiting Sales approval from someone on your team.","action":null,"createDate":"27/04/2016 16:17:43.820683","createdBy":"F539408","modifyDate":"27/04/2016 16:17:43.820683","modifiedBy":"F539408","dismissed":"N","read":"N"},{"id":7263,"sid":"U893286","message":"Request C26837 for GENEVA 8084 is awaiting Sales approval from someone on your team.","action":null,"createDate":"27/04/2016 16:16:41.026105","createdBy":"F539408","modifyDate":"27/04/2016 16:16:41.026105","modifiedBy":"F539408","dismissed":"N","read":"N"},{"id":7242,"sid":"U893286","message":"Request C25328 for JAYCEE  TATSUHARA is awaiting Sales approval from someone on your team.","action":null,"createDate":"27/04/2016 11:27:28.915263","createdBy":"F539408","modifyDate":"27/04/2016 11:27:28.915263","modifiedBy":"F539408","dismissed":"N","read":"N"}];
	
	
    function init() {
        $scope.dateSelected;
        $scope.dateSelected1;
        $scope.abc;
        $scope.sometext;
        $scope.ckbxValue = false;
        $scope.ckbxValue2 = false;
        $scope.pickedDate = null;
        $scope.msg = "Hello World";
        $scope.labelid = "parentlabelId";
        $scope.labelvalue = "label comming from parent controller";
        $scope.textId = "parenttextId";
        $scope.placeholder = "Please type text here";
        $scope.checkboxId1 = "parentcheckboxId";
        $scope.checkboxValue = "Domino Pizza";
        $scope.checkboxId2 = "parentcheckboxId";
        $scope.checkboxValue2 = "Hut Pizza";
        $scope.dropdownid = vm.getDropdownId();
        $scope.dropdownitems = vm.dropdownItems();
        $scope.yesNoDropdownValue;
        $scope.dropdownValue;
        $scope.dtpickId = "parentdtpickId";
        $scope.accordId = "parentaccordId";
        $scope.firstTitle = "Static Header, assigned in Parent";
        $scope.firstContent = "This content is coming from parent also";
        $scope.accordionGroups = vm.getAccordionGroups();
        $scope.singleBtnAction;
        $scope.btnName = "Test Button";
        $scope.btnSingleId = "parentBtnSingleId";
        $scope.btnGroupId = "parentBtnGroupId";
        $scope.txtId = "parentTextId";
        $scope.parentCols = "80";
        $scope.parentRows = "10";
        $scope.txtInput = "Here is your text";
        $scope.fileUploadId = "parentFileUploadId";
        $scope.fileModelId = "parentFileModelId";
        $scope.selectedFile = "No file chosen";
        // horizontal menu
        $scope.hMenuId = "parentHMenuId";
        $scope.menuItems = vm.menuItems();
        // vertical menu tree like
        $scope.vMenuId = "parentHMenuId";
        $scope.launcherOptions = vm.menuItems();
        $scope.selectedNodes = vm.menuItems();
        // multiselect
        $scope.mselectId = "parentMSelectId";
        $scope.multiselectData = vm.multiselect();
        // spinners
        $scope.smlSinnerId = "parentsmlSinnerId";
        $scope.mdmSpinnerId = "parentmdmSpinnerId";
        $scope.lrgSinnerId = "parentlrgSinnerId";
        $scope.gridDataSample = [{ "clientName": "test", "sid": "12345", "goLiveDate": "03-March-2016", $$treeLevel: "0" },
            { "clientName": "test1", "sid": "12345", "goLiveDate": "03-March-2016", $$treeLevel: "1" },
            { "clientName": "test2", "sid": "12345", "goLiveDate": "03-March-2016", $$treeLevel: "2" },
            { "clientName": "test2", "sid": "12345", "goLiveDate": "03-March-2016", "$$treeLevel": "2" },
            { "clientName": "test01", "sid": "12345", "goLiveDate": "03-March-2016", "$$treeLevel": "0" },
            { "clientName": "test02", "sid": "12345", "goLiveDate": "03-March-2016", "$$treeLevel": "1" },
            { "clientName": "test02", "sid": "12345", "goLiveDate": "03-March-2016", "$$treeLevel": "1" },
            { "clientName": "test03", "sid": "12345", "goLiveDate": "03-March-2016", "$$treeLevel": "2" },
            { "clientName": "test04", "sid": "12345", "goLiveDate": "03-March-2016", "$$treeLevel": "2" }
        ];
        $scope.columnDefinitionsSample = [
            {
                name: 'Investment Manager',
                field: 'clientName',
                width: '200'
            },
            {
                name: 'SID',
                field: 'sid',
                width: '200'
            },
            {
                name: 'Go Live Date',
                field: 'goLiveDate',
                width: '200'
            }
        ];
        $scope.gridConfig = {};
        $scope.gridId="falconGrid";
        $scope.startDate = new Date();
        $scope.endDate = new Date();
        $scope.onChangeDate =  function(){
        	alert("1")
        }
        $scope.gridConfig.enableHorizontalScrollbar = uiGridConstants.scrollbars.NEVER;
    	$scope.gridConfig.enableVerticalScrollbar = uiGridConstants.scrollbars.NEVER;
    	 $scope.gridConfig.columnDefs = vm.getHeaders();
       
        $timeout(function(){
        	$scope.gridConfig.data = vm.getGridData();
        	$scope.gridConfig.totalItems = 10;
        	$scope.gridConfig.paginationPageSize =2; 
        },5000)
        //$scope.gridConfig.data = vm.getGridData();
    	$scope.gridConfig.totalItems = 10;
		$scope.gridConfig.enableFiltering = true;		
		$scope.gridConfig.enableSorting = true;	
		$scope.gridConfig.enableColumnMoving = true;
		
		var isBEPagination = true;//App config
		$scope.gridConfig.filterConfig = {};
		if(isBEPagination){
			$scope.gridConfig.enablePagination = true;
			//No of rows per page which is configurable at client side
			$scope.gridConfig.useExternalPagination = true;
			$scope.gridConfig.paginationCallBackFn = function(filterConfig){
				console.error("Pagination Config:"+JSON.stringify(filterConfig));
			};
		}
		var isBESorting = true;//App config
        if(isBESorting){
        	$scope.gridConfig.useExternalSorting = true;
        	$scope.gridConfig.sortCallBackFn = function(filterConfig){
				console.error("Sorting Config:"+JSON.stringify(filterConfig));
			};
		}
        
        var isBEFiltering = true;//App config
        if(isBEFiltering){
        	$scope.gridConfig.useExternalFiltering = true;
        	$scope.gridConfig.filterCallBackFn = function(filterConfig){
				console.error("Filter Config:"+JSON.stringify(filterConfig));
			};
		}
        
        var isEnableRowSelection = true;
        if(isEnableRowSelection){
        	$scope.gridConfig.enableRowSelection = true;
    		$scope.gridConfig.enableSelectAll = true;
        	$scope.gridConfig.rowSelectionCallBackFn = function(selectedRows){
				console.error("Selected Rows:"+JSON.stringify(selectedRows));
			};
		}
		$scope.navMenuData = [{"menuItem":"My Team Task","id":"MyTeamTask","subMenuItems":[{"filter":"TX_TASK_STATUS IN ('Completed','Not Applicable','Terminated') AND ID_ASSIGNED_TEAM = {teamId}","name":"Outbox"},{"filter":"TX_TASK_STATUS IN ('Draft','Not Started','In Progress','Need More Info','On Hold') AND ID_ASSIGNED_TEAM = {teamId}","name":"Inbox"}]},{"menuItem":"My Task","id":"MyTask","subMenuItems":[{"filter":"TX_TASK_STATUS IN ('Draft','Not Started','In Progress','Need More Info','On Hold') AND ID_ASSIGNED_SID = {sId}","name":"Inbox"},{"filter":"TX_TASK_STATUS IN ('Completed','Not Applicable','Terminated') AND ID_ASSIGNED_TEAM = {teamId}","name":"Outbox"}]}];
        $scope.lstUserInterface = [
            {id:1, resourceId : "onbReqName", mandatory : true, visible: true, editable : false},
            {id:2, resourceId : "onReqID", mandatory : true, visible: true, editable : false}
        ];
        $scope.test = function (){
            coltRuleService.applyRulesService(this.lstUserInterface);
        }
    }

    $scope.onButtonClick = function()
    {
        console.log("Button clicked");
    };
    
    $scope.onClickMenuItem = function()
    {
    	console.log("onClickMenuItem from parent controller");
    };

    $scope.onCheckboxChange = function()
    {
            console.log("Checkbox changed  ");
    };

    $scope.onDropdownChange = function(message)
    {
        if ( message )
        {
            console.log("Dropdown changed to "+message);
        }
    };

    $scope.onYesNoDropdownChange = function(message)
    {
        if ( message )
        {
            if ( angular.isDefined(message.id) )
            {
                console.log("Yes/No Dropdown changed to id="+message.id);
            }
            else
            {
                console.log("Yes/No Dropdown changed to "+message);
            }
        }
    };

    vm.getDropdownId = function () {
        return "mydropdownId";
    };

    vm.dropdownItems = function () {
        return [{ id: 1, name: 'black', shade: 'dark' }, { id: 2, name: 'white', shade: 'light', notAnOption: true },
            { id: 3, name: 'red', shade: 'dark' },
            { id: 4, name: 'blue', shade: 'dark', notAnOption: true },
            { id: 5, name: 'yellow', shade: 'light', notAnOption: false }];
    };
    vm.getAccordionGroups = function () {
        return [
            {
                title: 'Dynamic Group Header - 1',
                content: 'Dynamic Group Body - 1',
                isOpen: true
            },
            {
                title: 'Dynamic Group Header - 2',
                content: 'Dynamic Group Body - 2',
                isOpen: false
            },
            {
                title: 'Dynamic Group Header - 3',
                content: 'Dynamic Group Body - 3',
                isOpen: false
            }
        ];
    };
    vm.menuItems = function () {
        return [{
            name: "Item1",
            href: "#",
            children: [{
                name: "SubItem1",
                href: "#"
            },
                {
                    name: "SubItem2",
                    href: "#"
                }]
        },
            {
                name: "Single",
                href: "#"
            },
            {
                name: "Item2",
                href: "#",
                children: [{
                    name: "SubItem3",
                    href: "#"
                },
                    {
                        name: "SubItem4",
                        href: "#"
                    },
                    {
                        name: "SubItem5",
                        href: "#"
                    }]
            },
            {
                name: "Item3",
                href: "#",
                children: [{
                    name: "SubItem51",
                    href: "#",
                    hasChildren: false
                },
                    {
                        name: "SubItem61",
                        href: "#",
                        children: [{
                            name: "SubItem61_child",
                            href: "#"
                        }]
                    },
                    {
                        name: "SubItem31",
                        href: "#",
                        children: [{
                            name: "SubItem311_child",
                            href: "#",
                            children: [{
                                name: "SubItem3111_child",
                                href: "#"
                            },
                                {
                                    name: "SubItem3211_child",
                                    href: "#"
                                },
                                {
                                    name: "SubItem3311_child",
                                    href: "#"
                                }]
                        },
                            {
                                name: "SubItem321_child",
                                href: "#"
                            },
                            {
                                name: "SubItem331_child",
                                href: "#"
                            }]
                    },
                    {
                        name: "SubItem41",
                        href: "#",
                        children: [{
                            name: "SubItem411_child",
                            href: "#",
                            children: [{
                                name: "SubItem4111",
                                href: "#"
                            },
                                {
                                    name: "SubItem4112",
                                    href: "#"
                                },
                                {
                                    name: "SubItem4113",
                                    href: "#",
                                    children: [{
                                        name: "SubItem41131",
                                        href: "#"
                                    },
                                        {
                                            name: "SubItem41132",
                                            href: "#"
                                        },
                                        {
                                            name: "SubItem41133",
                                            href: "#",
                                            children: [{
                                                name: "SubItem411331",
                                                href: "#"
                                            },
                                                {
                                                    name: "SubItem411332",
                                                    href: "#"
                                                },
                                                {
                                                    name: "SubItem411333",
                                                    href: "#"
                                                }]
                                        }]
                                }]
                        }]
                    }]
            }];
    };
    vm.launcherOptions = function () {
        return [{
            label: 'I want to', style: 'jpmm-bold',
            children: [{ label: 'Onboard a Client', style: 'jpmm', url: '#' }, {
                label: 'Create a prospect',
                style: 'jpmm'
            }, { label: 'Create a contact', style: 'jpmm' }]
        }, {
            label: 'Request List', style: 'jpmm-bold',
            children: [{
                label: 'My Requests',
                url: '#',
                style: 'jpmm'
            }, {
                label: 'My Team Requests',
                url: '#',
                style: 'jpmm'
            }]
        }, {
            label: 'Work List', style: 'jpmm-bold',
            children: [{
                label: 'Inbox',
                url: '#',
                style: 'jpmm'
            }, {
                label: 'Outbox',
                url: '#',
                style: 'jpmm'
            }, {
                label: 'My Team Inbox', url: '#',
                style: 'jpmm'
            }, { label: 'My Team Outbox', url: '#', style: 'jpmm' },
                {
                    label: 'Pending Assignment', url: '#',
                    style: 'jpmm'
                },
                {
                    label: 'Initiated by Frontoffice', url: '#',
                    style: 'jpmm'
                }]
        }, {
            label: 'Workflow Monitoring', style: 'jpmm-bold',
            children: [
                { label: 'Prime Brokerage Dashboard', style: 'jpmm', url: '#' },
                { label: 'ACCE Dashboard', style: 'jpmm', url: '#' },
                { label: 'C&FS Dashboard', style: 'jpmm', url: '#' },
                {
                    label: 'BlackRock New Fund Go Live Project',
                    style: 'jpmm',
                    iconAfter: 'jpmmicon jpmmicon-delete',
                    url: '#',
                    height: 741
                },
                {
                    label: 'Items Before Vacation',
                    style: 'jpmm',
                    url: '#',
                    iconAfter: 'jpmmicon jpmmicon-delete',
                    width: 400,
                    height: 400
                }]
        }, {
            label: 'Metrics',
            style: 'jpmm-bold',
            children: [{
                label: 'Workflow Activity Efficiently Metrics',
                style: 'jpmm',
                url: '#',
                width: 400,
                height: 400
            },
                {
                    label: 'Length of Review Time Metrics', style: 'jpmm', url: '#',
                    width: 400,
                    height: 400
                }]
        },
            {
                label: 'Utilities', style: 'jpmm-bold', children: [{
                label: 'Party Search',
                url: '#',
                style: 'jpmm'
            },
                {
                    label: 'Contact Search',
                    style: 'jpmm',
                    url: '#'
                },
                {
                    label: 'Coverage Search',
                    style: 'jpmm',
                    url: '#'
                }, {
                    label: 'Document Search',
                    style: 'jpmm',
                    url: '#'
                }
            ]
            }];
    };
    vm.multiselect = function () {
        return [
            { id: 1, name: 'Adam', email: 'adam@email.com', age: 12, country: 'United States' },
            { id: 2, name: 'Amalie', email: 'amalie@email.com', age: 12, country: 'Argentina' },
            { id: 3, name: 'Estefan�a', email: 'estefania@email.com', age: 21, country: 'Argentina' },
            { id: 4, name: 'Adrian', email: 'adrian@email.com', age: 21, country: 'Ecuador' },
            { id: 5, name: 'Wladimir', email: 'wladimir@email.com', age: 30, country: 'Ecuador' },
            { id: 6, name: 'Samantha', email: 'samantha@email.com', age: 30, country: 'United States' },
            { id: 7, name: 'Nicole', email: 'nicole@email.com', age: 43, country: 'Colombia' },
            { id: 8, name: 'Natasha', email: 'natasha@email.com', age: 54, country: 'Ecuador' },
            { id: 9, name: 'Michael', email: 'michael@email.com', age: 15, country: 'Colombia' },
            { id: 10, name: 'Nicol�s', email: 'nicolas@email.com', age: 43, country: 'Colombia' }
        ];
    };
    
    vm.getHeaders = function() {
		return [ {
			"name" : "Request ID",
			"field" : "requestId",
			"type":"string",
			 "cellTemplate": '<div >' +
             '<a href="javascript:void(0)" ng-click="grid.appScope.$parent.showMe()">{{row.entity.requestId}}</a>' +
             '</div>'
		},  {
			"name" : "Request Date",
            "field" : "requestDate",
            "type" : "date",
            "filterHeaderTemplate" : '<div style="display: inline;"><falcon-date-picker id="startDate"   placeholder="Start Date"  model="startDate" width="6"> </div> <div style="display: inline;"> <falcon-date-picker id="endDate" placeholder="End Date" model="endDate" width="6"></div>'
		}]
	}
	
    vm.getGridData = function() {
		return [ {
			"requestId" : 1,
			"requestTitle" : "JPMC AS EA FOR",
			"requestDate" : new Date()
		}, {
			"requestId" : 2,
			"requestTitle" : "BOA AS EA FOR",
			"requestDate" : new Date()
		},{
			"requestId" : 3,
			"requestTitle" : "JPMC AS EA FOR",
			"requestDate" : new Date()
		}, {
			"requestId" : 4,
			"requestTitle" : "BOA AS EA FOR",
			"requestDate" : new Date()
		},{
			"requestId" : 5,
			"requestTitle" : "JPMC AS EA FOR",
			"requestDate" : new Date()
		}, {
			"requestId" : 6,
			"requestTitle" : "BOA AS EA FOR",
			"requestDate" : new Date()
		},{
			"requestId" : 7,
			"requestTitle" : "JPMC AS EA FOR",
			"requestDate" : new Date()
		}, {
			"requestId" : 8,
			"requestTitle" : "BOA AS EA FOR",
			"requestDate" : new Date()
		},{
			"requestId" : 9,
			"requestTitle" : "JPMC AS EA FOR",
			"requestDate" : new Date()
		}, {
			"requestId" : 10,
			"requestTitle" : "BOA AS EA FOR",
			"requestDate" : new Date()
		}]
	}

    init();

    vm.onClick = function ()
    {
        console.log("Button clicked");
    };

});