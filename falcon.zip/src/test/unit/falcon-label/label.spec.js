describe("A label test2", function () {
    var compile;
    var scope;
    var directiveElem;


    beforeEach(function ()
    {
        angular.module('falcon.label');

        inject(function($compile, $rootScope){
            compile = $compile;
            scope = $rootScope.$new();
            scope.testValue="My Test Label";
            scope.id="idLabelTest";
            console.log(scope);
        });

        directiveElem = getCompiledElement();
        console.log(directiveElem);
    });

    function getCompiledElement(){
        var element = angular.element('<falcon-label value="{{testValue}}" id="{{idLabel}}"/>');
        var compiledElement = compile(element)(scope);
        scope.$digest();
        return compiledElement;
    }

    it('should applied template', function ()
    {
        console.log(directiveElem);
        //expect(directiveElem.html()).not.toEqual('');
        //var isolated = directiveElem.isolateScope();
        //console.log(isolated);
        //expect(isolated).toBeDefined();
        //expect(isolated.value).toEqual('My Test Label');
    });

    //it('should have another-person element', function () {
    //    expect(directiveElem.find('another-directive').length).toEqual(1);
    //});
});