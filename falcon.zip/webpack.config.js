var path = require("path");
var webpack = require('webpack');
var ExtractTextPlugin = require("extract-text-webpack-plugin");
var HtmlWebpackPlugin = require('html-webpack-plugin');

var appName = "falcon";

module.exports = {
    node: {
        child_process: 'empty',
        fs: 'empty'
    },
    context: path.join(__dirname, "."),
    devtool: 'source-map',
    module: {
        loaders: [{
            test: /\.less$/,
            loader: "style!css!less"
        }, {
            test: /\.css$/,
            loader: "style!css"
        },{
            exclude: path.join(__dirname, "/app/falconTest.html"),
            test: /\.html$/,
            loader: 'ngtemplate!html'
        },{
            test: /\.json$/,
            loader: "file?name=[name].[ext]"
        }, {
            test: /\.(woff|eot|ttf|svg|gif|png|ico|woff(2))(\?.*)?$/,
            loader: "url-loader?limit=1000000"
        }, {
            test: /\.js$/,
            loader: "source-map-loader"
        }]
    },
    output : {
        filename : appName + "-[name].js",
        path : path.join(__dirname, "dist"),
        publicPath : "",
        sourceMapFilename : "debugging/[file].map"
    },
    entry: {
        webpackDevServer: 'webpack/hot/dev-server',
        less: "./src/less/falcon.less",
        components: "./src/app/falcon.js",
        test: "./src/app/falconTest.js"
    },
    plugins: [new webpack.ProvidePlugin({
        $: "jquery",
        jQuery: "jquery",
        "window.jQuery": "jquery"
    }),
        new webpack.DefinePlugin({
            "require.specified": "require.resolve"
        }), new ExtractTextPlugin(appName + "-[name].css"),
        new HtmlWebpackPlugin({
            hash: true,
            title: 'Falcon Components',
            filename: 'index.html',
            template: './src/test/index.html'
        }),
        new HtmlWebpackPlugin({
            hash : true,
            title : 'Falcon Test',
            filename : 'falconTest.html',
            template : 'src/app/falconTest.html'
        })],
    resolve: {
        alias: {
            'angular': 'angular',
			'jquery' : 'jquery/dist/jquery.js',
			'jquery-ui' : 'jquery-ui/jquery-ui.js',
            'window.angular': 'angular',
            'bootstrap-css' : 'bootstrap/dist/css/bootstrap.css',
			'bootstrap-theme-css' : 'bootstrap/dist/css/bootstrap-theme.css',
			'bootstrap-js' : 'bootstrap/dist/js/bootstrap.js',
            'ui-bootstrap': 'angular-ui-bootstrap/dist/ui-bootstrap.js',
            'ui-bootstrap-tpls': 'angular-ui-bootstrap/dist/ui-bootstrap-tpls.js',
			'ngAnimate' : 'angular-animate/angular-animate.js',
			'angular-ui-router':'angular-ui-router/release/angular-ui-router.js',
            'angular-file-upload': 'angular-file-upload/dist/angular-file-upload.js',
            'angular-ui-grid-js' : 'angular-ui-grid/ui-grid.js',
			'angular-ui-grid-css' : 'angular-ui-grid/ui-grid.css',
            'treeControl': 'angular-tree-control/angular-tree-control.js',
            'ngSanitize': 'angular-sanitize',
            'uiSelect': 'angular-ui-select/select.js',
            'ngDialog': 'ng-dialog/js/ngDialog.js',
			'angular-ui-notification-js' : 'angular-ui-notification/dist/angular-ui-notification.js',
			'angular-ui-notification-css' : 'angular-ui-notification/dist/angular-ui-notification.css'
        },
        extensions: ['', '.webpack.js', '.web.js', '.js', '.json']
    },
    resolveLoader: {
        root: [__dirname, path.join(__dirname, "node_modules")]
    }
};
