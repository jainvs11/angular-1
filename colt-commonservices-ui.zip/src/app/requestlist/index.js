require("falcon-components-js");
require("falcon-components-less");

require("./requestList.css");

require("angular-loading-bar-js");
require("angular-loading-bar-css");

require("ui-layout-js");
require("ui-layout-css");

const requestListController = require('./requestListController.js');
const requestListService = require('./requestListService.js');

var requestListApp = angular.module("commonservices-requestList", ['angular-loading-bar','falcon','ui.layout']).service("requestListService",
    requestListService).controller("requestListController", requestListController).config(function(cfpLoadingBarProvider) {
        cfpLoadingBarProvider.includeSpinner = true;
        cfpLoadingBarProvider.spinnerTemplate = '<div id="loading-bar-spinner"><div class="spinner-icon"></div></div>'});

requestListApp.run(['falconMessagingClientService', function(falconMessagingClientService) {
    falconMessagingClientService.init('MyClient', null, ['event_to_coltportal']);
}]);