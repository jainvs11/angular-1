function RequestListService($http, $timeout) {

    this.getRequestList = function(filterConfig) {
        console.log(JSON.stringify(filterConfig));
        return $http.post("rpm/getrequestlistdata",filterConfig, {
            "headers": {
                "Accept": "application/json"
            }
        });
    };

    this.getColumnDefs = function() {
        return [
            { field: 'requestId', name: 'Request ID', cellTemplate: '<a class="ui-grid-cell-contents" ng-click="grid.appScope.$parent.showMe(row.entity.requestId)" href="javascript:void(0);">{{ COL_FIELD }}</a>'},

            { field: 'requestBusiness', name: 'Requesting LOB' },
            { field: 'requestType', name: 'Request Type' },

            { field: 'requestStatus', name: 'Request Status' },

            { field: 'requestParent', name: 'Request Parent' },
            { field: 'requestTitle', name: 'Request Title' },

            { field: 'lastRequestAction', name: 'Last Request Action' },
            { field: 'lastRequestActionContext', name: 'Last Request Action Context' },

            { field: 'requestedBy', name: 'Requested By' },
            { field: 'requestedDate', name: 'Requested Date' },

            { field: 'modifiedBy', name: 'Modified By' },
            { field: 'modifiedDate', name: 'Modified Date' },

            { field: 'createdBy', name: 'Created By' },
            { field: 'createdDate', name: 'Created Date' }
        ];
    };
}
module.exports = RequestListService;