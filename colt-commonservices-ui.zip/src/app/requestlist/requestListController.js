module.exports = function($scope,$http,falconMessagingClientService, uiGridConstants, requestListService) {
    var that = this;

    $scope.selectedTaskList = [];
    that.init = function() {
    	$scope.filterConfig = {
    			startPage : 1,
    			pageSize : 20,
    			orderBy : {

    			},
    			searchParams : [],
    			taskCategory : "REQUEST-LIST",
    			taskType : "INDIVIDUAL"
    	};
    	$scope.leftNavData = [{"menuItem":"My Request List","id":"myrequestlist"}];
        //requestListService.setLeftNavItems($scope);
        $scope.gridConfig = {};
        $scope.gridId = "falconGrid";
        $scope.styleProps = "height:712px;";
        $scope.gridConfig.rowHeight = 40;
        $scope.gridConfig.enableHorizontalScrollbar = uiGridConstants.scrollbars.NEVER;
        $scope.gridConfig.enableVerticalScrollbar = uiGridConstants.scrollbars.NEVER;
        $scope.gridConfig.enableFiltering = true;
        $scope.gridConfig.enableSorting = true;
        $scope.gridConfig.enableColumnMoving = true;
        $scope.gridConfig.enableRowSelection = true;
        $scope.gridConfig.enableSelectAll = true;
        $scope.gridConfig.columnDefs = requestListService.getColumnDefs();

        var isBEPagination = true; // App config
        $scope.gridConfig.filterConfig = {};
        if (isBEPagination) {
            $scope.gridConfig.enablePagination = true;
            $scope.gridConfig.paginationPageSize = 20;
            // No of rows per page which is configurable at client side
            $scope.gridConfig.useExternalPagination = true;
            $scope.gridConfig.paginationCallBackFn = function(filterConfig) {
                console.info("Pagination Config:" + JSON.stringify(filterConfig));
                $scope.filterConfig.startPage=filterConfig.pageNumber;
                $scope.filterConfig.pageSize=filterConfig.pageSize;
                that.refreshTaskList();
            };
        }

        //Row selection
         $scope.gridConfig.rowSelectionCallBackFn = function(selectedRows) {
        	 $scope.selectedTaskList = selectedRows;
         };
        that.refreshTaskList();
    };

    that.refreshTaskList = function() {
        requestListService.getRequestList($scope.filterConfig).then(
            function(response) {
                $scope.gridConfig.data = response.data.requestList;
                $scope.gridConfig.totalItems = response.data.totalItems;
            }).finally(function() {
            $scope.loading = false;
        });
    };


    $scope.showMe = function(requestId){
        console.log('show me requestId ' + requestId);
        var data = new Map();
        var attributes = [];
        attributes.push( 'requestId=' + requestId);
        data.set('resourceName', 'ONBOARD_CLIENT');
        data.set('attributes', attributes );
        //send message to hub
        falconMessagingClientService.publish('event_to_coltportal', data);
    };

    that.init();
}