module.exports = function($scope, $uibModalInstance) {
    var _this = this;
    $scope.cancelAction = function() {
        $uibModalInstance.dismiss('close');
    };
}