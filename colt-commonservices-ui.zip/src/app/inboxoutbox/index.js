require('falcon-components-less');
require('falcon-components-js');
require("angular-loading-bar-js");
require("angular-loading-bar-css");
require("ui-layout-js");
require("ui-layout-css");
require("./inboxoutbox.css");

var commonServicesInboxOutboxCtrl = require('./inboxoutboxCtrl.js')
var inboxOutboxService = require('./inboxoutboxSrvc.js');
var inboxoutboxModel = require('./inboxoutboxModel.js')
var taskModelCtrl = require('./taskModelCtrl.js');
var statusModalCtrl = require('./statusModalCtrl.js');


var inboxOutboxApp = angular.module("commonservices-inboxoutbox", ['angular-loading-bar', 'falcon', 'ui.layout','falcon.messaging.client']).factory(
    "InboxOutboxModel", inboxoutboxModel).service("inboxOutboxService",inboxOutboxService).controller("commonServicesInboxOutboxCtrl",
    commonServicesInboxOutboxCtrl).controller("taskModelCtrl",
    taskModelCtrl).controller("statusModalCtrl",
    		statusModalCtrl).config(function(cfpLoadingBarProvider) {
    cfpLoadingBarProvider.includeSpinner = true;
    cfpLoadingBarProvider.spinnerTemplate = '<div id="loading-bar-spinner"><div class="spinner-icon"></div></div>';
});

inboxOutboxApp.run(['falconMessagingClientService', function(falconMessagingClientService) {
    falconMessagingClientService.init('MyClient', null, ['event_to_coltportal']);
}]);