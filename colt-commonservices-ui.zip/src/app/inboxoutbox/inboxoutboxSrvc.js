function InboxOutboxService($http) {

    this.getTaskList = function(filterConfig) {
        console.log(JSON.stringify(filterConfig));
        return $http.post("inboxoutbox/gettasklist",filterConfig, {
        //return $http.post("tasklist.get.json", filterConfig, {
            "headers": {
                "Accept": "application/json"
            }
        });
    }


    this.setLeftNavItems = function($scope) {
        $http({
            //url: "resources.get.json",
            url: "inboxoutbox/resources", 
            params: {
                "resourceType": "QUEUE_ITEM"
            },
            method: "GET"
        }).success(function(response) {
            var menuData = {};
            response.forEach(function(item) {
                if (item.resourceDetails.path) {
                    var menuArray = item.resourceDetails.path.split("/");
                    var defaultFilter = item.resourceDetails.defaultFilter;
                    if (menuData[menuArray[0]]) {
                        var subMenuArr = menuData[menuArray[0]];
                        var subMenuObj = {};
                        subMenuObj.filter = defaultFilter;
                        subMenuObj.name = menuArray[1];
                        subMenuArr.push(subMenuObj)
                    } else {
                        var subMenuArr = [];
                        var subMenuObj = {};
                        subMenuObj.filter = defaultFilter;
                        subMenuObj.name = menuArray[1];
                        subMenuArr.push(subMenuObj);
                        menuData[menuArray[0]] = subMenuArr;
                    }
                }
            });
            $scope.leftNavData = [];
            for (key in menuData) {
                var menuObj = {};
                menuObj.menuItem = key;
                menuObj.id = key.split(' ').join('');
                var menuItemsArr = menuData[key];
                menuItemsArr.sort(function(obj1, obj2) {
                    if (obj1.name > obj2.name) {
                        return 1;
                    } else if (obj1.name < obj2.name) {
                        return -1;
                    }
                    return 0;
                });
                menuObj.subMenuItems = menuItemsArr;
                $scope.leftNavData.push(menuObj);
            }

            $scope.leftNavData.sort(function(obj1, obj2) {
                if (obj1.menuItem > obj2.menuItem) {
                    return 1;
                } else if (obj1.name < obj2.name) {
                    return -1;
                }
                return 0;
            });
        });
    }

    this.getAssigneeList = function(teamId) {
        return $http({
            url: "inboxoutbox/teammembers/"+teamId,
            method: "GET"
        });
    }

    this.assignTask = function(assigneeId,selectedActionObj) {
        var requestPayload = {};
        requestPayload.sid = assigneeId;
        //requestPayload.taskId = selectedActionObj.taskId;
        requestPayload.taskId = 12345;
        return $http.get("assigntask.post.json", requestPayload, {
        //return $http.post(selectedActionObj.url, requestPayload,{
            "headers": {
                "Content-Type": "application/json"
            }
        });
    }

    this.grabTask = function(selectedActionObj) {
    	var requestPayload = {};
        requestPayload.sid = "loggedInId"; //TODO: It will take it from UserAuthDTO
        //requestPayload.taskId = selectedActionObj.taskId; //TODO: Fix at service lavel type
        requestPayload.taskId = 12345;
        return $http.get("grabtask.get.json", requestPayload,{
        //return $http.post(selectedActionObj.url, requestPayload,{
            "headers": {
                "Content-Type": "application/json"
            }
        });
    }
    
    this.unAssignTask = function(selectedActionObj) {
    	var requestPayload = {};
        requestPayload.sid = null;
        //requestPayload.taskId = selectedActionObj.taskId;
        requestPayload.taskId = 12345;
        return $http.get("unassign.get.json", requestPayload,{
        //return $http.post(selectedActionObj.url, requestPayload,{
            "headers": {
                "Content-Type": "application/json"
            }
        });
    }
    
    this.openStatusModal = function(uiModal){
        var modalInstance = uiModal.open({
            animation: true,
            templateUrl: 'status.html',
            controller: 'statusModalCtrl'
        });
    }

    this.getServiceDataType = function(type) {
        var serviceDataType = "";
        switch (type) {
            case "string":
                return "STRING"
            case "number":
                return "INT"
            case "DATE":
                return "DATE";
            default:
                return "object";
        }
    }
    
    this.getTaskActionBtnClass = function(actionName) {
        var styleClass = "";
        switch (actionName) {
            case "Grab":
                return "glyphicon glyphicon-thumbs-up text-success"
            case "Assign":
                return "glyphicon glyphicon-hand-up text-success"
            case "UnAssign":
                return "glyphicon glyphicon-hand-down text-success";
            default:
                return "";
        }
    }

    this.getColumnDefs = function() {

        return [{
            "name": "Request ID",
            "field": "requestId",
            "enableColumnResizing": true,
            "enableCellEdit": true,
            "enableColumnMoving": true,
            "type": "string"
        }, {
            "name": "Request Title",
            "field": "requestTitle",
            "enableColumnResizing": true,
            "enableColumnMoving": true,
            "type": "string"
        }, {
            "name": "Request Status",
            "field": "requestStatus",
            "enableColumnResizing": true,
            "enableColumnMoving": true,
            "type": "string"
        }, {
            "name": "Workflow ID",
            "field": "workflowId",
            "enableColumnResizing": true,
            "enableColumnMoving": true,
            "type": "string"
        }, {
            "name": "Workflow Status",
            "field": "workflowStatus",
            "enableColumnResizing": true,
            "enableColumnMoving": true,
            "type": "string"
        }, {
            "name": "Task ID",
            "field": "taskId",
            "enableColumnResizing": true,
            "enableColumnMoving": true,
            "cellTemplate": '<div class="ui-grid-cell-contents">' +
                '<a href="javascript:void(0)" ng-click="grid.appScope.$parent.onPublishAction(row.entity)">{{row.entity.taskId}}</a>' +
                '</div>',
            "type": "string"
        }, {
            "name": "Task Name",
            "field": "taskName",
            "enableColumnResizing": true,
            "enableColumnMoving": true,
            "type": "string"
        }, {
            "name": "Task Status",
            "field": "taskStatusDisplay",
            "enableColumnResizing": true,
            "enableColumnMoving": true,
            "cellTemplate": '<div>&nbsp;{{row.entity.taskStatusDisplay}} <span ng-class="{\'glyphicon glyphicon-adjust inprogress\': row.entity.taskStatusDisplay == \'In Progress\' , \'glyphicon glyphicon-ok completed\': row.entity.taskStatusDisplay == \'Completed\', \'glyphicon glyphicon-remove-circle terminated\': row.entity.taskStatusDisplay == \'Terminated\',\'glyphicon glyphicon-ban-circle onhold\': row.entity.taskStatusDisplay == \'On Hold\',\'glyphicon glyphicon-hand-down notapplicable\': row.entity.taskStatusDisplay == \'Not Applicable\',\'glyphicon glyphicon-education needmore\': row.entity.taskStatusDisplay == \'Need More Info\',\'glyphicon glyphicon-minus-sign notstarted\': row.entity.taskStatusDisplay == \'Not Started\' } "></span></div>',
            "type": "string"
        }, {
            "name": "Task Created Date",
            "field": "dateCreated",
            "enableColumnResizing": true,
            "enableColumnMoving": true,
            "type": "date",
            "width":"20%",
            "cellFilter": "date:\"yyyy-MM-dd HH:mm\"",
            "filterHeaderTemplate": '<div style="display: inline;"><falcon-date-picker id="startDate" on-change = "grid.appScope.$parent.onChangeDate()" placeholder="Start Date"  model="grid.appScope.$parent.startDate" width="6"> </div> <div style="display: inline;"> <falcon-date-picker id="endDate" placeholder="End Date" on-change = "grid.appScope.$parent.onChangeDate()" model="grid.appScope.$parent.endDate" width="6"></div>'
        }, {
            "name": "Task Assigned to User",
            "field": "assignedUserName",
            "enableColumnResizing": true,
            "enableColumnMoving": true,
            "type": "string"
        }, {
            "name": "Task Assigned to Team",
            "field": "assignedTeamName",
            "enableColumnResizing": true,
            "enableColumnMoving": true,
            "type": "string"
        },
        {
        	"name" : "",
            "field" : "actionList",
            "enableFiltering" : false,
            "enableSorting" : false,
            "cellTemplate": '<div class="btn-group" uib-dropdown dropdown-append-to-body id="actionDropdown" style="padding:4px 0px 0px 6px;width:100%"> <button id="btn-append-to-body" style="width:100%" type="button" class="btn btn-default btn-sm" uib-dropdown-toggle> Select Action <span class="caret"></span> </button> <ul class="dropdown-menu" uib-dropdown-menu role="menu" aria-labelledby="btn-append-to-body"> <li role="menuitem" ng-repeat="actionObj in row.entity.actionList"><a href="javascript:void(0)" ng-click="grid.appScope.$parent.selectedAction(actionObj)"><span class="{{actionObj.btnClass}}"></span> {{actionObj.name}}</a></li> </ul> </div>'
        }
        
        ];
    }
}
module.exports = InboxOutboxService;