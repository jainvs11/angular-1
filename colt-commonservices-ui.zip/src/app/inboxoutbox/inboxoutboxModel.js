module.exports = function() {
	function InboxOutboxModel(name, description, createdDate) {
		this.name = name || null;
		this.description = description || null;
		this.createdDate = createdDate || null;
	}
	return InboxOutboxModel;
}
