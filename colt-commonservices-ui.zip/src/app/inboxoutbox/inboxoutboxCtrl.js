module.exports = function($scope, $rootScope, $uibModal, uiGridConstants,
    $filter, inboxOutboxService, cfpLoadingBar,
    falconMessagingClientService) {
    var that = this;
    /**
     * Initialize the grid data
     */
    that.init = function() {

        $scope.filterConfig = {
            startPage: 1,
            pageSize: 20,
            orderBy: {

            },
            searchParams: [],
            taskCategory: "INBOX",
            taskType: "INDIVIDUAL"
        };
        $scope.startDate = new Date();
        $scope.endDate = new Date();
        $scope.leftNavData = [];
        inboxOutboxService.setLeftNavItems($scope);
        $scope.gridConfig = {};
        $scope.gridId = "falconGrid";
        $scope.styleProps = "height:712px;";
        $scope.gridConfig.rowHeight = 40;
        $scope.gridConfig.enableHorizontalScrollbar = uiGridConstants.scrollbars.NEVER;
        $scope.gridConfig.enableVerticalScrollbar = uiGridConstants.scrollbars.NEVER;
        $scope.gridConfig.enableFiltering = true;
        $scope.gridConfig.enableSorting = true;
        $scope.gridConfig.enableColumnMoving = true;
        $scope.gridConfig.enableRowSelection = true;
        $scope.gridConfig.enableSelectAll = true;
        $scope.gridConfig.columnDefs = inboxOutboxService.getColumnDefs();

        var isBEPagination = true; // App config
        $scope.gridConfig.filterConfig = {};
        if (isBEPagination) {
            $scope.gridConfig.enablePagination = true;
            $scope.gridConfig.paginationPageSize = 20;
            // No of rows per page which is configurable at client side
            $scope.gridConfig.useExternalPagination = true;
            $scope.gridConfig.paginationCallBackFn = function(filterConfig) {
                console.log("Pagination Config:" +
                    JSON.stringify(filterConfig));
                $scope.filterConfig.startPage = filterConfig.pageNumber;
                $scope.filterConfig.pageSize = filterConfig.pageSize;
                that.refreshTaskList();
            };
        }
        var isBESorting = true; // App config
        if (isBESorting) {
            $scope.gridConfig.useExternalSorting = true;
            $scope.gridConfig.sortCallBackFn = function(filterConfig) {
                console.log("Sorting Config:" + JSON.stringify(filterConfig));
                $scope.filterConfig.orderBy = {};
                $scope.filterConfig.orderBy.field = filterConfig.field;
                $scope.filterConfig.orderBy.sortType = filterConfig.sortType;
                that.refreshTaskList();
            };
        }

        var isBEFiltering = true; // App config
        if (isBEFiltering) {
            $scope.gridConfig.useExternalFiltering = true;
            $scope.gridConfig.filterCallBackFn = function(filterConfig) {
                $scope.filterConfig.searchParams.forEach(function(itemObj) {
                    if (that.isExternalSearchParam(itemObj.attributeName)) {
                        filterConfig.searchParams.push(itemObj);
                    }
                })
                $scope.filterConfig.searchParams = filterConfig.searchParams;
                $scope.filterConfig.searchParams.forEach(function(itemObj) {
                    itemObj.attributeType = inboxOutboxService
                        .getServiceDataType(itemObj.attributeType);
                    itemObj.condition = itemObj.condition || "LIKE"; // TODO later change
                })
                console.log("Filter Config:" + JSON.stringify(filterConfig));
                that.refreshTaskList();
            };
        }

        // Row selection
        $scope.gridConfig.rowSelectionCallBackFn = function(selectedRows) {
            $scope.selectedTaskList = selectedRows;
        };
        that.refreshTaskList();
    }

    that.isExternalSearchParam = function(searchParam) {
        var externalSearchParams = ['dateCreated_startDate', 'dateCreated_endDate'];
        return ['dateCreated_startDate', 'dateCreated_endDate'].indexOf(searchParam) > -1;
    }

    that.refreshTaskList = function() {
        inboxOutboxService.getTaskList($scope.filterConfig).then(
            function(response) {
                $scope.gridConfig.totalItems = response.data.totalItems;
                var taskList = response.data.tasks;
                taskList.forEach(function(taskObj) {
                    taskObj.actionList = [];
                    that.generateActionList(taskObj);
                })
                $scope.gridConfig.data = taskList;
            })
    };

    that.generateActionList = function(taskObj) {
    	var taskActionObj = JSON.parse(taskObj.actions);
    	taskActionObj.taskActions.forEach(function(taskAction) {
    		var actionObj = {};
            actionObj.id = taskAction.name + "_" + taskObj.taskId;
            actionObj.name = taskAction.name;
            actionObj.assignedTeam = taskObj.assignedTeam;
            actionObj.assignedToId = taskObj.assignedToId;
            actionObj.url = taskAction.url;
            actionObj.btnClass = inboxOutboxService.getTaskActionBtnClass(taskAction.name);;
            actionObj.taskId = taskObj.taskId;
            taskObj.actionList.push(actionObj);   
        });
    	//console.log("TaskActions:"+JSON.stringify(taskObj.actionList));
    }

    that.generateTaskAction = function(actionName, itemObj) {
        var actionObj = {};
        actionObj.id = itemObj.taskId + "_" + actionName;
        actionObj.name = actionName;
        return actionObj;
    }

    // ******************* EVENTS SECTION **************************

    $scope.selectedAction = function(selectedActionObj) {
        if (selectedActionObj.name == "Grab") {
            inboxOutboxService.grabTask(selectedActionObj).then(
                function(response) {
                    $rootScope.header = "Message";
                    $rootScope.statusMessage = response.data.message;
                    inboxOutboxService.openStatusModal($uibModal);
                });
        }
        if (selectedActionObj.name == "Assign") {
        	var assigneeList = [];
            inboxOutboxService.getAssigneeList(selectedActionObj.assignedTeam).then(function(response) {
            	assigneeList = response.data;
            	var modalInstance = $uibModal.open({
                    animation: true,
                    templateUrl: 'assignTask.html',
                    controller: 'taskModelCtrl',
                    bindToController: true,
                    resolve: {
                        selectedActionObj: function() {
                            return selectedActionObj;
                        },
                        assigneeList: function() {
                            return assigneeList;
                        }
                    }
                });
            });
        }
        if (selectedActionObj.name == "UnAssign") {
            inboxOutboxService.unAssignTask(selectedActionObj).then(
                function(response) {
                	 $rootScope.header = "Message";
                     $rootScope.statusMessage = response.data.message;
                    inboxOutboxService.openStatusModal($uibModal);
                });
        }
    };

    $scope.onPublishAction = function(taskObj) {
        var data = new Map();
        var attributes = [];
        attributes.push('taskId=' + taskObj.taskId);
        data.set('resourceName', 'NCMR_Client_Data');
        data.set('attributes', attributes);
        // send message to hub
        falconMessagingClientService.publish('event_to_coltportal', data);
        console.log("Message has been published to open task screen");
    };

    $scope.onClickMenuItem = function(taskType, taskCategory) {
        $scope.filterConfig.taskType = (taskType === "My Team Task" ? "TEAM" :
            "INDIVIDUAL");
        $scope.filterConfig.taskCategory = taskCategory.toUpperCase();
        $scope.filterConfig.pageSize = 20;
        $scope.filterConfig.startPage = 1;
        $scope.filterConfig.searchParams = [];
        $scope.filterConfig.orderBy = {};
        that.refreshTaskList();
    }

    $scope.status = {
        isopen: false
    };

    $scope.$watch("startDate", function(newVal, oldVal) {
        if (newVal != oldVal) {
            $scope.filterConfig.searchParams = $scope.filterConfig.searchParams.filter(function(itemObj) {
                return itemObj.attributeName !== "dateCreated_startDate";
            });
            if (newVal) {
                var startDateFilter = {};
                startDateFilter.attributeName = "dateCreated_startDate";
                startDateFilter.attributeValue = $filter('date')(newVal, 'yyyy-MM-dd HH:mm:ss', 'UTC');
                startDateFilter.attributeType = "DATE";
                startDateFilter.condition = "GREATER_THAN_EQUAL";
                $scope.filterConfig.searchParams.push(startDateFilter);
            }
            that.refreshTaskList();
        }
    });

    $scope.$watch("endDate", function(newVal, oldVal) {
        if (newVal != oldVal) {
            $scope.filterConfig.searchParams = $scope.filterConfig.searchParams.filter(function(itemObj) {
                return itemObj.attributeName !== "dateCreated_endDate";
            })
            if (newVal) {
                var endDateFilter = {};
                endDateFilter.attributeName = "dateCreated_endDate";
                endDateFilter.attributeValue = $filter('date')(newVal, 'yyyy-MM-dd HH:mm:ss', 'UTC');
                endDateFilter.attributeType = "DATE";
                endDateFilter.condition = "LESS_THAN_EQUAL";
                $scope.filterConfig.searchParams.push(endDateFilter);
            }
            that.refreshTaskList();
        }
    });
    that.init();
}