module.exports = function($scope, $rootScope, inboxOutboxService, $uibModal, $uibModalInstance, selectedActionObj,assigneeList) {
    var _this = this;
    $scope.selectedAssignee = "";
    $scope.selectedActionObj = selectedActionObj;
    $scope.assigneeList = assigneeList;

    $scope.assignTask = function() {
        inboxOutboxService.assignTask($scope.selectedAssignee, $scope.selectedActionObj).then(function(response) {
        	 $uibModalInstance.dismiss('close');
            var assigneeObj = _this.getAssigneeObj();
            $rootScope.header = "Message";
            $rootScope.statusMessage = "Task(s) assigned successfully to " + assigneeObj.name + " / " + assigneeObj.sid;
            inboxOutboxService.openStatusModal($uibModal);
        });
    };

    this.getAssigneeObj = function() {
        return $scope.assigneeList.filter(function(itemObj) {
            return itemObj.sid === $scope.selectedAssignee;
        })[0];
    }

    $scope.onChangeAssignee = function(selectedItem, item) {
        $scope.selectedAssignee = selectedItem;
    }
    
    $scope.cancelAction = function() {
        $uibModalInstance.dismiss('close');
    };
}