require('falcon-components-less');
require('falcon-components-js');

const commonServicesInboxOutboxCtrl = require('./bulkuploadCtrl.js')
const inboxOutboxService = require('./bulkuploadSrvc.js');
const inboxoutboxModel = require('./bulkuploadModel.js')
require('./FileSaver.js')