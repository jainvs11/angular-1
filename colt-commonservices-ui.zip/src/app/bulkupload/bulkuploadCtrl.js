
var coltCommonServicesApp = angular.module('coltCommonServicesApp', ['falcon']);

        coltCommonServicesApp.controller('coltCommonServicesController', ['$scope', 'fileUpload', 'postToServer', 'postToServerExcel', 'templateService', 'uploadService', 'uiGridConstants', function($scope, fileUpload, postToServer, postToServerExcel, templateService, uploadService, uiGridConstants){
			
            $scope.uploadFile = function(){
                var file = $scope.myFile;
                console.dir(file);
                var uploadUrl = "bulkupload/bulkuploadfile";
                fileUpload.uploadFileToUrl(file, uploadUrl).success(function(data) {
				
					var obj = new Object();	
					obj.bulkuploadId = data.bulkUploadHeaderDto.uploadId;
					obj.templateType = data.bulkUploadHeaderDto.templateDescription;
					obj.uploadedBy = data.bulkUploadHeaderDto.createdBy;
					obj.uploadedTime = new Date(data.bulkUploadHeaderDto.created);
					obj.executeStatus =  (data.bulkUploadHeaderDto.totalRecords != null)?((data.bulkUploadHeaderDto.noOfExecutionErrors != null ? (data.bulkUploadHeaderDto.totalRecords - data.bulkUploadHeaderDto.noOfExecutionErrors): '0') + '/' + data.bulkUploadHeaderDto.totalRecords):'';
					obj.templateName = data.bulkUploadHeaderDto.templateName;
					obj.execute = "Execute";
					obj.download = "";
					obj.delete = "";
					
					$scope.fileUploadGridOptions.data.unshift(obj);
					
				}).error(function() {
				});
            };
			
			
			$scope.downloadFile = function(selectedTemplate) {
				if ( selectedTemplate == undefined ) {
					return;
				}
					
				postToServerExcel.postDataHandler("bulkupload/downloadtemplate", { templateName : selectedTemplate.id }).success(function(data) {
					var blob = new Blob([data], {type: "application/vnd.ms-excel"});
					saveAs(blob, selectedTemplate.name + '.xlsx');
				}).error(function() {
					alert('Error in downloadFile');
				});
			};
			
			
			templateService.getTemplatesList($scope);
			uploadService.getUploadedData($scope);
						
			$scope.fileUploadArr = [];
		
			
			$scope.executeBulkUpload = function(rowData) {
				postToServer.postDataHandler("bulkupload/executebulkupload", { loadId : rowData.bulkuploadId, action : 'EXECUTE_BUSSINESS'}).success(function(data) {
						rowData.executeStatus =  (data.bulkUploadHeaderDto.totalRecords != null)?((data.bulkUploadHeaderDto.noOfExecutionErrors != null ? (data.bulkUploadHeaderDto.totalRecords - data.bulkUploadHeaderDto.noOfExecutionErrors): '0') + '/' + data.bulkUploadHeaderDto.totalRecords):'';
						rowData.executedBy = data.bulkUploadHeaderDto.processedBy;
						rowData.executedTime = data.bulkUploadHeaderDto.processed;
				}).error(function() {
					alert('Error in executeBulkUpload');
				});
			};
			
			$scope.downloadBulkUploadedData = function(rowData) {
				postToServerExcel.postDataHandler("bulkupload/downloadBulkUploadedData", { uploadId : rowData.bulkuploadId, templateName : rowData.templateName, templateDescription: rowData.templateType}).success(function(data) {
					var blob = new Blob([data], {type: "application/vnd.ms-excel"});
					saveAs(blob, rowData.templateName + '_Load_Id_' + rowData.bulkuploadId + '.xlsx');
				}).error(function() {
					alert('Error in downloadBulkUploadedData');
				});
			};
			
			$scope.deleteBulkUploadData = function(rowData) {
				$scope.elementTodelete = rowData;
				postToServer.postDataHandler("bulkupload/deletebulkuploadData", { uploadId : rowData.bulkuploadId}).success(function(data) {
					  var index = $scope.fileUploadGridOptions.data.indexOf($scope.elementTodelete);
					  $scope.fileUploadGridOptions.data.splice(index, 1);
					  $scope.elementTodelete = null;
				}).error(function() {
					alert('Error in deleteBulkUploadData');
				});
			};
			
			/*
			$scope.validateBulkUpload = function(rowData) {
				alert("Bulk Upload Execute");
				postToServer.postDataHandler("bulkupload/executebulkupload", { loadId : rowData.bulkuploadId, action : 'VALIDATE_BUSSINESS'}).success(function(data) {
					 alert('Helooooo');
						rowData.validateStatus = (data.bulkUploadHeaderDto.totalRecords - data.bulkUploadHeaderDto.noOfValidationErrors) + '/' + data.bulkUploadHeaderDto.totalRecords;
						$scope.fileUploadGridOptions.data.refreshRows();
					 
				}).error(function() {
					alert('Hiiii');
					$scope.fileUploadArr.push({bulkuploadId : "2", uploadedTime : "2016", uploadedBy : "Gilman, Sean"});
				});
			};
			*/
			
			$scope.fileUploadGridOptions = {
					enableSorting: true,
					minRowsToShow: 25,
					enableHorizontalScrollbar: uiGridConstants.scrollbars.NEVER,
					enableVerticalScrollbar: uiGridConstants.scrollbars.ALWAYS,
					enableColumnMenus: false,
					enableColumnResizing: true,
					columnDefs: [
						{name: 'Bulk Upload Id', 	field: 'bulkuploadId', enableColumnResizing: true},
						{name: 'Bulk Upload Type', field: 'templateType', enableColumnResizing: true},
						{name: 'Upload Date', field: 'uploadedTime', enableColumnResizing: true, type: 'date', cellFilter: 'date:"yyyy-MM-dd HH:mm"'},
						{name: 'Uploaded By', 	field: 'uploadedBy', enableColumnResizing: true},
						{name: 'Processed Date', field: 'executedTime', enableColumnResizing: true, type: 'date', cellFilter: 'date:"yyyy-MM-dd HH:mm"'},
						{name: 'Processed By', 	field: 'executedBy', enableColumnResizing: true},
						{name: 'Processed Status', 	field: 'executeStatus', enableColumnResizing: true},
						{name: "Template Name",field: 'templateName',visible:false},	
						{name: "Execute", width: 75, enableColumnResizing: true, enableSorting: false,
							cellTemplate:'<div class="ui-grid-cell-contents" style="text-align: center;"><button class="btn btn-jpmm btn-default" ng-click="grid.appScope.executeBulkUpload(row.entity)">Execute</button></div>'},
						{name: 'Download', field: 'name', enableColumnResizing: true,  cellTemplate: '<div class="ui-grid-cell-contents" style="text-align: center;" ng-click="grid.appScope.downloadBulkUploadedData(row.entity)"><span class="jpmmicon jpmmicon-import" style="cursor: pointer; color:#020000;font-weight: bold;" ></span></div>'},
						{name: 'Delete', field: 'name', enableColumnResizing: true,cellTemplate: '<div class="ui-grid-cell-contents" style="text-align: center;" ng-click="grid.appScope.deleteBulkUploadData(row.entity)"><span class="jpmmicon jpmmicon-close" style="cursor: pointer; color:#af0000;font-weight: bold;" ></span></div>'}
					],
					data: $scope.fileUploadArr
			};
			
			$scope.tabs = [{
				title: 'Bulk Upload',
				url: ''
			}];

			$scope.currentTab = '';

			$scope.onClickTab = function (tab) {
				$scope.currentTab = tab.url;
			}
    
			$scope.isActiveTab = function(tabUrl) {
				return tabUrl == $scope.currentTab;
			}


        }]);
		
		
		coltCommonServicesApp.service('templateService', ['postToServer', function (postToServer) {
			this.getTemplatesList = function(scope) {
				postToServer.postDataHandler("bulkupload/gettemplateslist", { sid : 'F533838'}).success(function(response) {
					
					var availableTemplates = [];
					
					var templates_ = response.templates;
					for(var i=0; i<templates_.length; i++) {
						var temp_ = templates_[i];
						var templateObj = new Object();
						templateObj.id = temp_.templateName;
						templateObj.name = temp_.templateDescription;
		
						availableTemplates.push(templateObj);
						
					}
					
					scope.bulkuploadtemplates = availableTemplates;
					if ( scope.bulkuploadtemplates != undefined)
					{
						scope.selectedTemplate = scope.bulkuploadtemplates[0];
					}
					
					
					
				}).error(function() {
					 alert("Error Getting the List of Templates.");
				});
			};
		}]);
		
		coltCommonServicesApp.service('uploadService', ['postToServer', function (postToServer) {
			this.getUploadedData = function(scope) {
				postToServer.postDataHandler("bulkupload/getuploadeddata", { sid : 'F533838'}).success(function(response) {
					var bulkUploadResponses = [];
					var bulkUploadResponse_ = response.lstBulkUploadResponseDto;
					for(var i=0; i<bulkUploadResponse_.length; i++) {
						var data = bulkUploadResponse_[i];
						var obj = new Object();	
						obj.bulkuploadId = data.bulkUploadHeaderDto.uploadId;
						obj.templateType = data.bulkUploadHeaderDto.templateDescription;
						obj.uploadedBy = data.bulkUploadHeaderDto.createdBy;
						obj.uploadedTime = new Date(data.bulkUploadHeaderDto.created);
						obj.executeStatus =  (data.bulkUploadHeaderDto.totalRecords != null)?((data.bulkUploadHeaderDto.noOfExecutionErrors != null ? (data.bulkUploadHeaderDto.totalRecords - data.bulkUploadHeaderDto.noOfExecutionErrors): '0') + '/' + data.bulkUploadHeaderDto.totalRecords):'';
						obj.executedBy = data.bulkUploadHeaderDto.processedBy;
						obj.executedTime = data.bulkUploadHeaderDto.processed;
						obj.templateName = data.bulkUploadHeaderDto.templateName;
						obj.execute = "Execute";
						obj.download = "";
						obj.delete = "";
						bulkUploadResponses.push(obj);						
					}
					scope.fileUploadGridOptions.data = bulkUploadResponses;					
				}).error(function() {
					 alert("Error Getting the Uploaded List");
				});
			};
		}]);
		
		
		coltCommonServicesApp.service('fileUpload', ['$http',function ($http) {
             this.uploadFileToUrl = function(file, uploadUrl){
                var fd = new FormData();
                fd.append('file', file);

                return $http.post(uploadUrl, fd, {
                    transformRequest: angular.identity,
                    headers: {'Content-Type': undefined}
                });
            }
        }]);

        coltCommonServicesApp.service('postToServer', ['$http', function ($http) {
            this.postDataHandler = function(url, data){
			   
			   return $http.post(url, data, {
                    headers: {'Content-Type': 'application/json'}
                });
            }
        }]);
		
		coltCommonServicesApp.service('postToServerExcel', ['$http', function ($http) {
            this.postDataHandler = function(url, data){
			   
			   return $http.post(url, data, {
					responseType: 'arraybuffer',
                    headers: {'Content-Type': 'application/json',
					'Accept': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'}
					 
                });
            }
        }]);

        coltCommonServicesApp.directive('fileModel', ['$parse', function ($parse) {
            return {
                restrict: 'A',
                link: function(scope, element, attrs) {
                    var model = $parse(attrs.fileModel);
                    var modelSetter = model.assign;

                    element.bind('change', function(){
                        scope.$apply(function(){
                            modelSetter(scope, element[0].files[0]);
                        });
                    });
                }
            };
        }]);