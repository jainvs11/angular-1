var path = require("path");
var webpack = require('webpack');
var ExtractTextPlugin = require("extract-text-webpack-plugin");
var HtmlWebpackPlugin = require('html-webpack-plugin')
var CopyWebpackPlugin = require("copy-webpack-plugin")

var appName = "coltcommonservices";
module.exports = {
    node: {
        child_process: 'empty',
        fs: 'empty'
    },
    context: path.join(__dirname, "src"),
    devtool: 'source-map',
    module: {
        loaders: [{
            test: /\.css$/,
            loader: ExtractTextPlugin.extract("style-loader",
                "css-loader")
        }, {
            test: /\.less$/,
            loader: ExtractTextPlugin.extract("style-loader",
                "css-loader!less-loader")
        }, {
            test: /\.html$/,
            loader: "file?name=[name].[ext]"
        }, {
            test: /\.json$/,
            loader: "file?name=[name].[ext]"
        }, {
            test: /\.(woff|eot|ttf|svg|gif|png|ico|woff(2))(\?.*)?$/,
            loader: 'url-loader?limit=1000000'
        }, {
            test: /bootstrap\/js\//,
            loader: 'imports?jQuery=jquery'
        }]
    },
    entry: {
        webpackDevServer: 'webpack/hot/dev-server',
        inboxoutbox: "./app/inboxoutbox/index.js",
        bulkupload: "./app/bulkupload/index.js",
        requestlist: "./app/requestlist/index.js"
    },
    output: {
        filename: appName + "-[name].js",
        path: path.join(__dirname, "dist/app"),
        publicPath: "",
        sourceMapFilename: "debugging/[file].map"
    },
    plugins: [
        new webpack.DefinePlugin({
            "require.specified": "require.resolve"
        }),
        new ExtractTextPlugin(appName + "-[name].css", {
            publicPath: ''
        }),
        new HtmlWebpackPlugin({
            hash: true,
            title: 'Inbox/Outbox',
            filename: 'inboxoutbox.html',
            template: 'src/app/inboxoutbox/inboxoutbox.html'
        }),
        new HtmlWebpackPlugin({
            hash: true,
            title: 'Bulkupload',
            filename: 'bulkupload.html',
            template: 'src/app/bulkupload/bulkupload.html'
        }),
        new HtmlWebpackPlugin({
            hash: true,
            title: 'Request List',
            filename: 'requestList.html',
            template: 'src/app/requestlist/requestList.html'
        }),
        new webpack.HotModuleReplacementPlugin(), new CopyWebpackPlugin([{
            from: 'mock-api',
            to: '.'
        }])
    ],
    resolve: {
        alias: {
            'angular-loading-bar-js': 'angular-loading-bar/build/loading-bar.js',
            'angular-loading-bar-css': 'angular-loading-bar/build/loading-bar.css',
            'falcon-components-js': "falcon/dist/falcon-components.js",
            'falcon-components-less': "falcon/dist/falcon-less.js",
            'ui-layout-js': 'angular-ui-layout/src/ui-layout.js',
            'ui-layout-css': 'angular-ui-layout/src/ui-layout.css'
        },
        extensions: ['', '.webpack.js', '.web.js', '.js', '.json']
    },
    resolveLoader: {
        root: [__dirname, path.join(__dirname, "node_modules")]
    }
};