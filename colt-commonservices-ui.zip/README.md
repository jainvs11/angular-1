
# COLT PORTAL UI
This is a project where we will colt UI is going to be implemented

## Setup


### Install and build
** Assumption node and npm is installed

* run "npm install"
* run "npm start"
* open  http://localhost:80/index.html


### To verify colt-framework-ui components;

* verify that from colt-framework2\colt-framework2-ui\colt-framework2-components\dist\app\customComponents.js is present in js directory

